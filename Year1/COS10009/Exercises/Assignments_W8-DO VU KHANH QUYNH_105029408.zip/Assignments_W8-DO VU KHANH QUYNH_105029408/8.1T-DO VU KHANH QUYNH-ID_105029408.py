# Task 8.1 T - use the code from the previous tasks to complete this:
GENRE = {
    1 : "Pop",
    2 : "Classic",
    3 : "Jazz",
    4 : "Rock"
}

class Album():
    # NB: you will need to add tracks to the following and finish the initialiser
    
    # complete the missing code:
    def __init__(self, title, artist, genre, tracks):
        self.genre = genre
        self.title = title
        self.artist = artist
        self.tracks = tracks

class Track():
    def __init__(self, name, location):
        self.name = name
        self.location = location

# Reads in and returns a single track from the given file
def read_track(music_file):
    # Fill in the missing code
    name = music_file.readline().strip()
    location = music_file.readline().strip()
    return Track(name, location)


# Returns an array of tracks read from the given file
def read_tracks(music_file):
    count = int(music_file.readline().strip())
    tracks = []
    i = 0
    # Put a while loop here which increments an index to read the tracks
    while i < count:
        track = read_track(music_file)
        tracks.append(track)
        i += 1
    return tracks

# Takes an array of tracks and prints them to the terminal
def print_tracks(tracks):
    # print all the tracks use: tracks[x] to access each track.
    i = 0
    while i < len(tracks):
        print_track(tracks[i])
        i += 1

# Reads in and returns a single album from the given file, with all its tracks
def read_album(music_file):
    # read in all the Album's fields/attributes including all the tracks
    # complete the missing code
    album_artist = music_file.readline().strip()
    album_title = music_file.readline().strip()
    album_genre = int(music_file.readline().strip())
    tracks = read_tracks(music_file)
    album = Album(album_title, album_artist, album_genre, tracks)
    return album

# Takes a single album and prints it to the terminal along with all its tracks
def print_album(album):
    # print out all the albums fields/attributes
    print(album.title)
    print(album.artist)
    # print(album.genre)
    # Complete the missing code.
    print(f"Genre is {album.genre}")
    print(f"{GENRE[album.genre]}")
    # print out the tracks
    print_tracks(album.tracks)

# Takes a single track and prints it to the terminal
def print_track(track):
    print(f"{track.name}")
    print(f"{track.location}")

# Reads in an album from a file and then print the album to the terminal
def main():
    file_name = 'album.txt'
    with open(file_name, "r") as music_file:
        album = read_album(music_file)
        music_file.close()
        print_album(album)

if __name__ == "__main__":
    main()