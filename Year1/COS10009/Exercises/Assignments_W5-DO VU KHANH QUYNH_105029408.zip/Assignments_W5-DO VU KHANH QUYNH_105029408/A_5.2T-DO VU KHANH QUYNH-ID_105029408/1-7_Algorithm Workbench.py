#1. Write an if statement that assigns 20 to the variable y, and assigns 40 to the variable z if the variable x is greater than 100. 
x = 100
if x > 100:
    y = 20
    z = 40

#2. Write an if statement that assigns 10 to the variable b and 50 to the variable c if the variable a is equal to 100. 
a = 100
b = 0
c = 0
if a == 100:
    print("a is equal to 100: ")
    b += 10
    c += 50
    print(f"b is: {b} and c is: {c}\n")

#3. Write an if-else statement that assigns 0 to the variable b if the variable a is less than 10. Otherwise, it should assign 99 to the variable b. 
A = int(input("Please enter the nummber: "))
if A < 10:
    B = 0
else:
    B = 99
print(f"B is equal to: {B}")

#4. The following code contains several nested if-else statements. 
# Unfortunately, it was written without proper alignment and indentation. 
# Rewrite the code and use the proper conventions of alignment and indentation. 
score = int(input("Please enter the score: "))
if score >= 90:
    print("Your grade is A.")
elif score >= 80:
    print("Your grade is B.")
elif score >= 70:
    print("Your grade is C.")
elif score >= 60:
    print("Your grade is D.")
else:
    print("Your grade is F.")

# 5. Write nested decision structures that perform the following: If amount1 is greater than 10 and 
# amount2 is less than 100, display the greater of amount1 and amount2.
amount_1 = int(input("Please enter the num: "))
amount_2 = int(input("Please enter the num: "))
if amount_1 > 10 and amount_2 < 100:
    if amount_1 > amount_2:
        print(f"The greater of amount 1 is {amount_1}")
    else:
        print(f"The greater of amount 2 is {amount_2}")
else:
    print("You need that amount 1 is greater than 10, and amount 2 is less than 100")

# 6. Write an if-else statement that assigns True to the again variable if the score variable is within 
# the range of 40 to 49. If the score variable’s value is outside this range, assign False to the again 
# variable.
Score = int(input("Please Enter the number: "))
if 40<= Score <= 49:
    again = True
    print("Correct\n")
else:
    again = False
    print("Incorrect\n")

# 7. Write an if-else statement that determines whether the points variable is outside the range of 9 
# to 51. If the variable’s value is outside this range it should display “Invalid points.” Otherwise, it 
# should display “Valid points.” 
points = int(input("Please enter the point: "))
if 9 <= points <= 51:
    print("Valid points.\n")
else:
    print("Invalid points.\n")