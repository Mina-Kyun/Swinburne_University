import turtle
# 8. Write an if statement that uses the turtle graphics library to determine whether the turtle’s 
# heading is in the range of 0 degrees to 45 degrees (including 0 and 45 in the range). If so, raise 
# the turtle’s pen.
heading = turtle.heading()
if 0 <= heading <= 45:
    turtle.penup()
turtle.done()


# 9. Write an if statement that uses the turtle graphics library to determine whether the turtle’s pen 
# size is greater than 1 or the pen color is red. If so, set the pen size to 1 and the pen color to blue.
pen_size = turtle.pensize()
pen_color = turtle.color()
if pen_size > 1 or pen_color == "black":
    turtle.pensize(1)
    turtle.color("blue")
turtle.done()

# 10. Write an if statement that uses the turtle graphics library to determine whether the turtle is 
# inside of a rectangle. The rectangle’s upper-left corner is at (100, 100) and its lower-right corner 
# is at (200, 200). If the turtle is inside the rectangle, hide the turtle. 
x = turtle.xcor()
y = turtle.ycor()
if 100 <= x <= 200 and 100 <= y <= 200:
    turtle.hideturtle()
turtle.done()

