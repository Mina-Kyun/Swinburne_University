# 1. Write a while loop that lets the user enter a number. The number should be multiplied by 10, 
# and the result assigned to a variable named product. The loop should iterate as long as product is 
# less than 100. 
product = 0
while product < 100:
    user_num = float(input("Please enter the number: "))
    product = user_num * 10
    print(f"The product is: {product}")
print("The loop should iterate as long as product is less than 100\n")

# 2. Write a while loop that asks the user to enter two numbers. The numbers should be added and 
# the sum displayed. The loop should ask the user if he or she wishes to perform the operation 
# again. If so, the loop should repeat, otherwise it should terminate. 
answer = "yes"
while answer.lower().strip() == "yes":
    num_1 = float(input("Please enter the first number: "))
    num_2 = float(input("Please enter the second number: "))
    total = num_1 + num_2
    print(f"The sum is: {total}")
    answer = input("Do you want to perform the operation again? (yes/no)")
print("Done!\n")

#3. Write a for loop that uses the range function to display all odd numbers between 1 and 100. 
for num in range(1, 101, 2):
    print(num)

# 4. Starting with a variable text containing an empty string, write a loop that prompts the user to 
# type a word. Add the user’s input to the end of text and then print the variable. The loop should 
# repeat while the length of text is less than 10 characters. 
text = " "
while len(text) < 10:
    word = input("Type a word: ")
    text += word
    print(f"Current chain: {text} while the leghth of text is {len(text)}")
print("The loop ends because the string has reached at least 10 characters.\n")

#5. Write a loop that calculates the total of the following series of numbers: 
i = 1
total = 0
while i <= 30:
    numerator = i
    denominator = 31 - i
    total += (numerator / denominator)
    i += 1
print(f"Sum of a series of numbers: {total:.2f}")