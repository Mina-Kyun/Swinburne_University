import input_functions as input_functions

# put your code below


class Track:
    # TODO: define the Track class with name and location attributes
    pass


def read_track():
    # TODO: prompt for and read the track name
    # TODO: prompt for and read the track location
    # TODO: create and return a Track object
    pass


def print_track(track):
    # TODO: print the track name
    # TODO: print the track location
    pass


def main():
    # TODO: call read_track() and print_track()
    pass


# leave this line
if __name__ == "__main__":
    main()
