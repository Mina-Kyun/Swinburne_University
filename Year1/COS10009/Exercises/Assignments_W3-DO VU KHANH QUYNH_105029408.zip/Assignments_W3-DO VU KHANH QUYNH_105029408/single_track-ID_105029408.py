import input_functions as input_function

class Track:
    def __init__(self, track_name: str, track_location: str):
        self.name = track_name
        self.location = track_location
        
def read_track():
    print("Enter track")
    track_name = input_function.read_string("Enter track name: ")
    track_location = input_function.read_string("Enter track location: ")
    track = Track(track_name, track_location)
    return track

def print_track(track):
    print(f"Track name: {track.name}\nTrack location: {track.location}")

def main():
    track = read_track()
    print_track(track)

if __name__ == "__main__":
    main()
