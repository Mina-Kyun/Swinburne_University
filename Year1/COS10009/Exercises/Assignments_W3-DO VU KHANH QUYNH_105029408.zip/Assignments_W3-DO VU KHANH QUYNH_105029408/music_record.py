import input_functions as input_functions

GENRE_NAMES = {
    1: "Pop",
    2: "Classic",
    3: "Jazz",
    4: "Rock"
}


class Album:
    # Optional: you may add an __init__ method
    pass


def read_album():
    print("Enter Album")

    # TODO: Read the album name (string)
    # album_name =

    # TODO: Read the artist name (string)
    # artist_name =

    # TODO: Read the genre number (integer between 1 and 4)
    # genre_number =

    album = Album()

    # TODO: Assign values to the album object
    # album.name =
    # album.artist =
    # album.genre =

    return album


def print_album(album):
    print("Album information is:")

    # TODO: Print album name
    # TODO: Print artist name
    # TODO: Print genre number
    # TODO: Print genre name using GENRE_NAMES dictionary


def main():
    album = read_album()
    print_album(album)


if __name__ == "__main__":
    main()
