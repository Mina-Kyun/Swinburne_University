# Acknowledgement to the original authors of the code on which this
# example is based.
require 'gosu'

SCREEN_HEIGHT = 400
SCREEN_WIDTH = 400

class GameWindow < Gosu::Window
  def initialize
    super(SCREEN_WIDTH, SCREEN_HEIGHT)
    self.caption = "Gosu Example"

    @done = false
    @is_blue = true
    @x = 30
    @y = 30

    @time = Gosu
  end

  def update
    close if @done 

    # input handling (no event queue like pygame, use button_down?/down?)
    if button_down?(Gosu::KB_LEFT)
      if @x > 0
        @x -= 3
      end
    end

    if button_down?(Gosu::KB_RIGHT)
      if @x < SCREEN_WIDTH - 61
        @x += 3
      end
    end

    if button_down?(Gosu::KB_UP)
      if @y > 0
        @y -= 3
      end
    end

    if button_down?(Gosu::KB_DOWN)
      if @y < SCREEN_HEIGHT - 61
        @y += 3
      end
    end

    puts "x is #{@x} y is #{@y} timer is #{Gosu.milliseconds}"
  end

  def draw
    # screen.fill((0, 0, 0))
    Gosu.draw_rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Gosu::Color::BLACK)

    if @is_blue
      color = Gosu::Color.rgb(0, 128, 255)
    else
      color = Gosu::Color.rgb(255, 100, 0)
    end

    # rect = pygame.Rect(x, y, 60, 60)
    Gosu.draw_rect(@x, @y, 60, 60, color)
  end

  def button_down(id)
    if id == Gosu::KB_ESCAPE
      @done = true
    end

    # toggle on space press (edge-triggered)
    if id == Gosu::KB_SPACE
      @is_blue = !@is_blue 
    end
  end
end

window = GameWindow.new
window.show