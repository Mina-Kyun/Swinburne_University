#include <stdio.h>
#include <string.h>
#include "terminal_user_input.h"

#define LOOP_COUNT 60

void print_silly_name(my_string name)
{
  int index;
  printf("%s is a", name.str);
  for(index = 0; index < LOOP_COUNT; index++)
  {
    printf(" silly");
  }
  printf("name!\n");
}

int main()
{
  my_string name;
  int index;
 
  name = read_string("What is your name? ");

  printf("Your name is: %s\n", name.str);

  // Move the following code into a procedure
  // ie: void print_silly_name(my_string name)
  if (strcmp(name.str, "Ted") == 0 || strcmp(name.str, "Fred") == 0)
  {
    printf("That is an AWSOME name!\n");
  }
  else
  {
    print_silly_name(name);
  }

  return 0;
}
