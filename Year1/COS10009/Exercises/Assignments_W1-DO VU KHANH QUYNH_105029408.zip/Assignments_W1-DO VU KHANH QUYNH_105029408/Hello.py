# Display print about "Hello Word"
print("Hello Word")
# Display print "Hello {objects}"
program = input("Enter the language program: ") #any language program that you want (e.g: ruby, python,...)
print(f"Hello {program}") #display the print