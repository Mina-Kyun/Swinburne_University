# Kế Hoạch Triển Khai: School Horror Survival Game

## Tổng Quan

Game kinh dị sinh tồn 3D góc nhìn thứ nhất được xây dựng trên Unity/Godot với C#. Triển khai theo kiến trúc Component-Based Entity System kết hợp MVC pattern, tập trung vào cơ chế stealth, quản lý tiếng động, và tránh tiếp xúc mắt với ma.

## Danh Sách Nhiệm Vụ

- [x] 1. Thiết lập cấu trúc dự án và các interface cốt lõi
  - Tạo cấu trúc thư mục cho Scripts, Scenes, Prefabs, Audio, UI
  - Định nghĩa các interface chính: IGameManager, IPlayerManager, IGhostManager, INoiseManager, IFloorManager
  - Định nghĩa các enum: GameState, GameResult, MovementSpeed, GhostType, GhostState, RoomType, SafeZoneType, ItemType
  - Thiết lập framework testing (NUnit cho Unity hoặc GUT cho Godot)
  - _Yêu cầu: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

- [ ] 2. Triển khai mô hình dữ liệu và trạng thái game
  - [x] 2.1 Tạo các class dữ liệu cốt lõi
    - Viết class PlayerData với các thuộc tính: Position, ViewDirection, CurrentFloor, MovementSpeed, NoiseLevel, IsInSafeZone
    - Viết class GhostData với các thuộc tính: GhostId, Type, Position, CurrentFloor, State, PatrolPath, DetectionRadius
    - Viết class FloorData, Room, Staircase với validation
    - Viết class GameStateData để quản lý trạng thái tổng thể
    - Viết class Inventory với giới hạn MAX_ITEMS = 10
    - Implement phương thức IsValid() cho tất cả các class dữ liệu
    - _Yêu cầu: 1.1, 2.1, 3.1, 11.1_

  - [ ]* 2.2 Viết property test cho mô hình dữ liệu
    - **Property 2: Noise Level Invariant**
    - **Validates: Yêu cầu 3.1**

  - [ ]* 2.3 Viết unit tests cho validation
    - Test PlayerData.IsValid() với các trường hợp edge case
    - Test GhostData.IsValid() với patrol path không hợp lệ
    - Test Staircase.IsValid() với kết nối tầng không hợp lệ
    - _Yêu cầu: 1.1, 2.4, 11.6_

- [ ] 3. Triển khai hệ thống Noise Manager
  - [x] 3.1 Tạo NoiseManager class
    - Implement UpdateNoise(deltaTime) để cập nhật noise theo thời gian
    - Implement AddNoise(amount) với clamping [0, 100]
    - Implement DecayNoise(deltaTime) để giảm noise về 0 sau 3 giây đứng yên
    - Implement OnPlayerMove(speed) để tăng noise theo tốc độ: Crouch +2/s, Walk +5/s, Run +10/s
    - Implement OnPlayerCollision() để tăng noise +20 khi va chạm
    - _Yêu cầu: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6_

  - [ ]* 3.2 Viết property test cho Noise Manager
    - **Property 2: Noise Level Invariant**
    - **Property 3: Noise Increase on Movement**
    - **Property 4: Noise Decay**
    - **Property 5: Collision Noise**
    - **Validates: Yêu cầu 3.1, 3.3, 3.4, 3.5, 3.6**

  - [ ]* 3.3 Viết unit tests cho Noise Manager
    - Test noise clamping khi vượt quá 100
    - Test decay time chính xác 3 giây
    - Test collision noise +20 điểm
    - _Yêu cầu: 2.6, 3.1, 3.3, 3.4_

- [ ] 4. Triển khai Player Manager và di chuyển
  - [x] 4.1 Tạo PlayerManager class
    - Implement Move(direction, speed) với collision detection
    - Implement ChangeFloor(targetFloor) để di chuyển giữa các tầng
    - Implement EnterRoom(room) để vào phòng
    - Implement GetPosition(), GetCurrentFloor(), GetNoiseLevel()
    - Implement GetViewDirection() và IsLookingAt(ghost) cho eye contact
    - Tích hợp với NoiseManager để cập nhật noise khi di chuyển
    - _Yêu cầu: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6_

  - [ ]* 4.2 Viết property test cho Player Manager
    - **Property 6: Movement Direction**
    - **Property 7: Floor Navigation**
    - **Property 8: Room Accessibility**
    - **Validates: Yêu cầu 2.1, 2.4, 2.5**

  - [ ]* 4.3 Viết unit tests cho Player Manager
    - Test di chuyển với collision (không đi qua tường)
    - Test chuyển tầng qua cầu thang
    - Test vào phòng có cửa đóng (không được phép)
    - _Yêu cầu: 2.1, 2.4, 2.5_

- [~] 5. Checkpoint - Kiểm tra hệ thống cơ bản
  - Đảm bảo tất cả tests pass, hỏi người dùng nếu có thắc mắc.

- [ ] 6. Triển khai Ghost Manager và AI
  - [x] 6.1 Tạo Ghost class và GhostManager
    - Viết Ghost class với các phương thức: Patrol(), Investigate(position), Chase(player), LoseTarget()
    - Implement CanDetectPlayer(player, noiseLevel) với logic: noise > 30 và distance < 10
    - Implement IsInDetectionRange(position) dựa trên DetectionRadius
    - Viết GhostManager với SpawnGhosts(count, types) để tạo ít nhất 3 loại Ghost
    - Implement UpdateGhostBehaviors(deltaTime) để cập nhật AI mỗi frame
    - Implement NotifyNoiseLevel(noiseLevel, position) để Ghost phản ứng với tiếng động
    - _Yêu cầu: 4.1, 4.2, 4.3, 4.5, 11.2_

  - [x] 6.2 Triển khai Ghost AI state machine
    - Implement Patrolling state: di chuyển theo PatrolPath
    - Implement Investigating state: di chuyển đến vị trí có tiếng động
    - Implement Chasing state: truy đuổi Player
    - Implement Searching state: tìm kiếm Player sau khi mất dấu
    - Implement chuyển đổi state dựa trên noise và detection
    - _Yêu cầu: 4.1, 4.2, 4.3_

  - [ ]* 6.3 Viết property test cho Ghost AI
    - **Property 9: Ghost Detection by Noise**
    - **Property 10: Ghost Patrol Behavior**
    - **Property 11: Ghost Chase on Detection**
    - **Property 12: Game Over on Caught**
    - **Validates: Yêu cầu 4.1, 4.2, 4.3, 4.4**

  - [ ]* 6.4 Viết unit tests cho Ghost AI
    - Test patrol path loop (quay lại điểm đầu)
    - Test detection với noise = 30 và distance = 10 (boundary case)
    - Test Ghost bắt Player khi distance < threshold
    - _Yêu cầu: 4.1, 4.2, 4.4_

- [ ] 7. Triển khai hệ thống Eye Contact
  - [x] 7.1 Tạo Eye Contact detection system
    - Implement IsLookingAt(ghost) trong PlayerManager: kiểm tra góc nhìn và line of sight
    - Implement NotifyEyeContact(ghost, player) trong GhostManager
    - Implement logic: khi eye contact xảy ra, Ghost chuyển sang Chasing ngay lập tức
    - Implement break eye contact: sau 1 giây không nhìn, hủy eye contact
    - _Yêu cầu: 5.1, 5.2, 5.3, 5.5_

  - [ ]* 7.2 Viết property test cho Eye Contact
    - **Property 18: Eye Contact Detection**
    - **Property 19: Eye Contact Immediate Detection**
    - **Property 20: Eye Contact Break**
    - **Validates: Yêu cầu 5.1, 5.2, 5.3, 5.5**

  - [ ]* 7.3 Viết unit tests cho Eye Contact
    - Test eye contact với Ghost ngoài tầm nhìn (có vật cản)
    - Test break eye contact sau đúng 1 giây
    - Test Ghost chuyển sang Chasing ngay lập tức
    - _Yêu cầu: 5.1, 5.2, 5.3, 5.5_

- [ ] 8. Triển khai Floor Manager và cấu trúc tầng
  - [x] 8.1 Tạo FloorManager class
    - Implement InitializeFloors() để tạo 5 tầng với bố cục khác nhau
    - Implement GetFloor(floorNumber), GetRoomsOnFloor(floorNumber)
    - Implement GetStaircases(floorNumber) và CanMoveBetweenFloors(from, to)
    - Implement GetSpiritualClubRoom() để trả về phòng câu lạc bộ tâm linh
    - Đảm bảo mỗi tầng có ít nhất một cầu thang kết nối
    - _Yêu cầu: 11.1, 11.3, 11.5, 11.6_

  - [x] 8.2 Tạo dữ liệu tầng và phòng
    - Định nghĩa layout cho 5 tầng với các phòng: Library, Classroom, PianoRoom, Gym, SwimmingPool, Hallway
    - Đặt Spiritual_Club_Room trên một trong các tầng
    - Tạo patrol paths cho Ghost trên mỗi tầng
    - _Yêu cầu: 11.1, 11.2, 11.3_

  - [ ]* 8.3 Viết property test cho Floor Manager
    - **Property 7: Floor Navigation**
    - **Property 27: Ghost Distribution**
    - **Property 28: Spiritual Club Room Existence**
    - **Validates: Yêu cầu 11.1, 11.2, 11.3, 11.5, 11.6**

  - [ ]* 8.4 Viết unit tests cho Floor Manager
    - Test connectivity giữa các tầng
    - Test Spiritual_Club_Room tồn tại duy nhất
    - Test mỗi tầng có ít nhất một cầu thang
    - _Yêu cầu: 11.3, 11.5, 11.6_

- [~] 9. Checkpoint - Kiểm tra hệ thống core gameplay
  - Đảm bảo tất cả tests pass, kiểm tra Player có thể di chuyển, Ghost có thể phát hiện và truy đuổi.

- [ ] 10. Triển khai Safe Zone Manager
  - [x] 10.1 Tạo SafeZoneManager class
    - Implement InitializeSafeZones() để tạo 5 safe zones: Locker, PianoRoom, Gym, SwimmingPool, Additional
    - Implement IsPlayerInSafeZone(player) để kiểm tra Player có trong safe zone không
    - Implement EnterSafeZone(player, zone): đặt Noise_Level về 0, đánh dấu IsInSafeZone = true
    - Implement ExitSafeZone(player): đánh dấu IsInSafeZone = false
    - Implement logic: Ghost không thể phát hiện Player trong safe zone
    - Implement logic: Ghost mất dấu Player sau 5 giây khi Player vào safe zone
    - _Yêu cầu: 1.3, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

  - [ ]* 10.2 Viết property test cho Safe Zone
    - **Property 13: Safe Zone Protection**
    - **Property 14: Safe Zone Noise Reset**
    - **Property 15: Ghost Behavior Independence in Safe Zone**
    - **Property 16: Safe Zone Exit Freedom**
    - **Property 17: Ghost Lose Target in Safe Zone**
    - **Property 29: Safe Zone Distribution**
    - **Validates: Yêu cầu 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 11.4**

  - [ ]* 10.3 Viết unit tests cho Safe Zone
    - Test noise reset về 0 khi vào safe zone
    - Test Ghost không phát hiện Player trong safe zone dù noise cao
    - Test Player có thể rời safe zone bất cứ lúc nào
    - Test Ghost mất dấu sau đúng 5 giây
    - _Yêu cầu: 6.2, 6.3, 6.5, 6.6_

- [ ] 11. Triển khai Item Manager và Holy Cross
  - [x] 11.1 Tạo ItemManager class
    - Implement InitializeItems() để khởi tạo vật phẩm
    - Implement PlaceHolyCross(spiritualClubRoom) để đặt Holy Cross tại phòng câu lạc bộ tâm linh
    - Implement PickupItem(item, player) để nhặt vật phẩm vào inventory
    - Implement UseItem(item, player, target) để sử dụng Holy Cross trên Main Ghost
    - Kiểm tra điều kiện: Player phải có Holy Cross và target phải là Main Ghost
    - _Yêu cầu: 1.4, 7.1, 7.2, 7.3, 7.4_

  - [x] 11.2 Triển khai logic Holy Cross
    - Implement OnPickup() để thêm Holy Cross vào inventory và đặt HasHolyCross = true
    - Implement OnUse() để tiêu diệt Main Ghost: đặt IsDefeated = true
    - Implement kiểm tra phạm vi sử dụng (Player phải gần Main Ghost)
    - _Yêu cầu: 7.3, 7.4, 7.5_

  - [ ]* 11.3 Viết property test cho Item Manager
    - **Property 21: Holy Cross Pickup**
    - **Property 22: Holy Cross Usage Condition**
    - **Property 23: Main Ghost Defeat**
    - **Validates: Yêu cầu 7.2, 7.3, 7.4, 7.5, 7.6**

  - [ ]* 11.4 Viết unit tests cho Holy Cross
    - Test pickup Holy Cross tại Spiritual_Club_Room
    - Test không thể sử dụng Holy Cross trên Ghost thường (chỉ Main Ghost)
    - Test Main Ghost bị tiêu diệt khi dùng Holy Cross
    - _Yêu cầu: 7.2, 7.4, 7.5_

- [ ] 12. Triển khai Escape Route và điều kiện thắng
  - [x] 12.1 Tạo Escape Route system
    - Implement khởi tạo ít nhất một Escape_Route trong game
    - Implement logic: khi Player đến Escape_Route, hiển thị tùy chọn thoát
    - Implement UseEscapeRoute(): kết thúc game với GameState = Victory và GameResult = EscapeRoute
    - Đảm bảo Player có thể sử dụng Escape Route ngay cả khi Ghost đang truy đuổi
    - _Yêu cầu: 1.5, 8.1, 8.2, 8.3, 8.4, 8.5_

  - [ ]* 12.2 Viết property test cho Escape Route
    - **Property 24: Escape Route Usage**
    - **Validates: Yêu cầu 8.2, 8.3, 8.5**

  - [ ]* 12.3 Viết unit tests cho Escape Route
    - Test escape route kết thúc game với Victory
    - Test escape route hoạt động khi Ghost đang chase
    - _Yêu cầu: 8.2, 8.3, 8.5_

- [ ] 13. Triển khai Game Manager và vòng đời game
  - [x] 13.1 Tạo GameManager class
    - Implement InitializeGame(): khởi tạo Player tại Library Floor 5, tạo Ghost, Safe Zones, Holy Cross, Escape Route
    - Implement StartGame(), PauseGame(), ResumeGame()
    - Implement EndGame(result): xử lý kết thúc game với GameResult
    - Implement CheckWinConditions(): kiểm tra điều kiện thắng (Escape Route hoặc Main Ghost defeated)
    - Implement TriggerGameOver(reason): xử lý thua game (bị Ghost bắt)
    - Điều phối giữa các manager: PlayerManager, GhostManager, NoiseManager, FloorManager, SafeZoneManager, ItemManager
    - _Yêu cầu: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 9.1, 9.2, 9.3_

  - [ ]* 13.2 Viết property test cho Game Manager
    - **Property 1: Khởi Tạo Game Đầy Đủ**
    - **Property 25: Game End Screen**
    - **Validates: Yêu cầu 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 9.4, 9.5**

  - [ ]* 13.3 Viết unit tests cho Game Manager
    - Test khởi tạo game: Player tại Library Floor 5
    - Test khởi tạo game: ít nhất 3 loại Ghost
    - Test khởi tạo game: 5 Safe Zones
    - Test khởi tạo game: Holy Cross tại Spiritual_Club_Room
    - Test khởi tạo game: ít nhất một Escape Route
    - Test điều kiện thắng: Escape Route
    - Test điều kiện thắng: Main Ghost defeated
    - Test điều kiện thua: Ghost bắt Player
    - _Yêu cầu: 1.1, 1.2, 1.3, 1.4, 1.5, 9.1, 9.2, 9.3_

- [~] 14. Checkpoint - Kiểm tra game logic hoàn chỉnh
  - Đảm bảo tất cả tests pass, kiểm tra có thể chơi từ đầu đến cuối với cả hai điều kiện thắng.

- [ ] 15. Triển khai UI Manager
  - [x] 15.1 Tạo UI Manager class
    - Implement UpdateFloorDisplay(floor) để hiển thị tầng hiện tại
    - Implement UpdateNoiseLevel(noiseLevel) để hiển thị mức độ tiếng động
    - Implement UpdateInventory(inventory) để hiển thị Holy Cross khi có
    - Implement ShowGhostDirectionIndicator(direction) để chỉ hướng Ghost gần nhất (không hiển thị khoảng cách)
    - Implement ShowSafeZonePrompt(zone) khi Player gần Safe Zone
    - Implement ShowControls() để hiển thị hướng dẫn điều khiển
    - _Yêu cầu: 10.1, 10.2, 10.3, 10.4, 10.5, 10.6_

  - [x] 15.2 Tạo UI screens
    - Implement ShowMainMenu() với tùy chọn: New Game, Load Game, Controls, Quit
    - Implement ShowPauseMenu() với tùy chọn: Resume, Save, Load, Main Menu
    - Implement ShowGameOverScreen(result) hiển thị kết quả thua
    - Implement ShowVictoryScreen(result) hiển thị kết quả thắng (Escape hoặc Defeated Main Ghost)
    - Cung cấp tùy chọn "Chơi lại" trên màn hình kết thúc
    - _Yêu cầu: 9.4, 9.5_

  - [ ]* 15.3 Viết property test cho UI Manager
    - **Property 26: UI State Synchronization**
    - **Validates: Yêu cầu 10.1, 10.2, 10.3, 10.6**

  - [ ]* 15.4 Viết unit tests cho UI Manager
    - Test UI cập nhật khi Floor thay đổi
    - Test UI cập nhật khi Noise Level thay đổi
    - Test UI hiển thị Holy Cross khi pickup
    - Test UI hiển thị màn hình kết thúc đúng
    - _Yêu cầu: 10.1, 10.2, 10.3, 9.4_

- [ ] 16. Triển khai Save/Load System
  - [x] 16.1 Tạo SaveLoadSystem class
    - Implement SaveGame(saveSlot): lưu PlayerData (vị trí, tầng, inventory, noise level)
    - Implement SaveGame(saveSlot): lưu GhostData (vị trí, trạng thái, patrol path)
    - Implement SaveGame(saveSlot): lưu Holy Cross status (đã nhặt chưa, Main Ghost defeated chưa)
    - Implement LoadGame(saveSlot): khôi phục tất cả trạng thái đã lưu
    - Implement CreateSaveData() để serialize game state thành JSON
    - Implement error handling: hiển thị thông báo lỗi nếu save/load thất bại
    - _Yêu cầu: 12.1, 12.2, 12.3, 12.4, 12.5, 12.6_

  - [ ]* 16.2 Viết property test cho Save/Load
    - **Property 30: Save/Load Round Trip**
    - **Validates: Yêu cầu 12.1, 12.2, 12.3, 12.4, 12.5**

  - [ ]* 16.3 Viết unit tests cho Save/Load
    - Test save và load vị trí Player
    - Test save và load trạng thái Ghost
    - Test save và load inventory (Holy Cross)
    - Test save và load Holy Cross status
    - Test error handling khi file không tồn tại
    - Test error handling khi file bị corrupt
    - _Yêu cầu: 12.1, 12.2, 12.3, 12.4, 12.5, 12.6_

- [ ] 17. Triển khai xử lý lỗi và edge cases
  - [x] 17.1 Implement error handling
    - Xử lý lỗi khởi tạo: không đủ Ghost, Floor, Safe Zone
    - Xử lý lỗi di chuyển: vị trí không hợp lệ, collision
    - Xử lý lỗi Ghost AI: patrol path không hợp lệ, không tìm được đường
    - Xử lý lỗi Save/Load: disk full, permission denied, file corrupt
    - Xử lý lỗi Item: sử dụng Holy Cross không hợp lệ
    - Xử lý lỗi State: state transition không hợp lệ
    - Implement clamping cho Noise Level [0, 100]
    - Implement backup collision check để tránh miss catch event
    - _Yêu cầu: 12.6_

  - [ ]* 17.2 Viết unit tests cho error handling
    - Test khởi tạo thất bại quay về Main Menu
    - Test di chuyển không hợp lệ giữ Player tại vị trí cũ
    - Test Ghost AI fallback khi patrol path lỗi
    - Test Save thất bại hiển thị thông báo
    - Test Load file corrupt hiển thị thông báo
    - Test Noise Level clamping
    - _Yêu cầu: 12.6_

- [ ] 18. Tích hợp và kết nối các thành phần
  - [x] 18.1 Kết nối tất cả managers
    - Kết nối PlayerManager với NoiseManager để cập nhật noise khi di chuyển
    - Kết nối NoiseManager với GhostManager để thông báo noise level
    - Kết nối GhostManager với PlayerManager để kiểm tra eye contact
    - Kết nối SafeZoneManager với GhostManager để vô hiệu hóa detection
    - Kết nối ItemManager với GameManager để trigger win condition
    - Kết nối UIManager với tất cả managers để cập nhật hiển thị
    - Kết nối SaveLoadSystem với GameManager để lưu/tải toàn bộ state
    - _Yêu cầu: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_

  - [ ]* 18.2 Viết integration tests
    - Test flow: Start → Move → Ghost detects → Chase → Enter Safe Zone → Ghost loses target
    - Test flow: Start → Find Holy Cross → Use on Main Ghost → Victory
    - Test flow: Start → Find Escape Route → Escape → Victory
    - Test flow: Start → Ghost catches Player → Game Over
    - Test flow: Eye contact → Immediate chase → Look away → Break contact
    - _Yêu cầu: 4.3, 5.2, 6.6, 7.5, 8.3, 9.1, 9.2, 9.3_

- [~] 19. Checkpoint cuối - Kiểm tra toàn bộ hệ thống
  - Đảm bảo tất cả tests pass, kiểm tra game có thể chơi hoàn chỉnh từ đầu đến cuối với tất cả các tính năng.

## Ghi Chú

- Các task đánh dấu `*` là optional và có thể bỏ qua để tạo MVP nhanh hơn
- Mỗi task tham chiếu đến yêu cầu cụ thể để đảm bảo traceability
- Các checkpoint đảm bảo validation từng bước
- Property tests xác minh tính đúng đắn phổ quát với 100 iterations
- Unit tests xác minh các ví dụ cụ thể và edge cases
- Integration tests kiểm tra luồng game hoàn chỉnh
