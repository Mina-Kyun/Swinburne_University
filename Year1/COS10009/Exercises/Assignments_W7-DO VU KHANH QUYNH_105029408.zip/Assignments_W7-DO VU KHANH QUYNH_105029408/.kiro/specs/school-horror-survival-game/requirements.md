# Tài Liệu Yêu Cầu

## Giới Thiệu

Game kinh dị sinh tồn lấy bối cảnh trường học về đêm, nơi một học sinh nữ bị kẹt lại và phải trốn tránh các thực thể ma quái để tìm đường thoát. Game tập trung vào yếu tố stealth, quản lý tiếng động, và tránh tiếp xúc mắt với ma.

## Thuật Ngữ

- **Game**: Hệ thống game kinh dị sinh tồn
- **Player**: Nhân vật người chơi điều khiển (học sinh nữ)
- **Ghost**: Thực thể ma quái trong game
- **Main_Ghost**: Ma chính có thể bị tiêu diệt bằng Holy_Cross
- **Safe_Zone**: Khu vực an toàn nơi Player có thể ẩn náu
- **Holy_Cross**: Vật phẩm đặc biệt để tiêu diệt Main_Ghost
- **Noise_Level**: Mức độ tiếng động do Player tạo ra
- **Eye_Contact**: Trạng thái khi Player nhìn trực tiếp vào Ghost
- **Floor**: Tầng của trường học (từ tầng 1 đến tầng 5)
- **Spiritual_Club_Room**: Phòng câu lạc bộ tâm linh chứa Holy_Cross
- **Escape_Route**: Đường thoát khỏi trường học
- **Game_State**: Trạng thái hiện tại của game (đang chơi, thắng, thua)

## Yêu Cầu

### Yêu Cầu 1: Khởi Tạo Game

**User Story:** Là người chơi, tôi muốn bắt đầu game với cài đặt ban đầu, để có thể bắt đầu trải nghiệm sinh tồn.

#### Tiêu Chí Chấp Nhận

1. WHEN game được khởi động, THE Game SHALL đặt Player tại thư viện ở Floor 5
2. WHEN game được khởi động, THE Game SHALL tạo ít nhất 3 loại Ghost khác nhau trên các Floor
3. WHEN game được khởi động, THE Game SHALL khởi tạo 5 Safe_Zone (tủ đồ, phòng piano, phòng thể dục, khu bơi, và một vị trí bổ sung)
4. WHEN game được khởi động, THE Game SHALL đặt Holy_Cross tại Spiritual_Club_Room
5. WHEN game được khởi động, THE Game SHALL thiết lập ít nhất một Escape_Route
6. THE Game SHALL khởi tạo Noise_Level của Player ở mức 0

### Yêu Cầu 2: Di Chuyển Người Chơi

**User Story:** Là người chơi, tôi muốn di chuyển nhân vật qua các tầng và phòng, để khám phá trường học và tìm đường thoát.

#### Tiêu Chí Chấp Nhận

1. WHEN người chơi nhấn phím di chuyển, THE Game SHALL di chuyển Player theo hướng được chỉ định
2. WHEN Player di chuyển nhanh (chạy), THE Game SHALL tăng Noise_Level
3. WHEN Player di chuyển chậm (đi rón rén), THE Game SHALL giữ Noise_Level ở mức thấp
4. THE Game SHALL cho phép Player di chuyển giữa các Floor thông qua cầu thang
5. THE Game SHALL cho phép Player vào các phòng có cửa mở
6. WHEN Player va chạm với vật thể, THE Game SHALL tăng Noise_Level

### Yêu Cầu 3: Hệ Thống Tiếng Động

**User Story:** Là người chơi, tôi muốn hệ thống tiếng động ảnh hưởng đến khả năng phát hiện của ma, để tạo yếu tố chiến thuật trong việc di chuyển.

#### Tiêu Chí Chấp Nhận

1. THE Game SHALL theo dõi Noise_Level của Player trong phạm vi từ 0 đến 100
2. WHEN Noise_Level vượt quá 30, THE Game SHALL tăng phạm vi phát hiện của Ghost gần nhất
3. WHEN Player đứng yên trong 3 giây, THE Game SHALL giảm Noise_Level xuống 0
4. WHEN Player va chạm với đồ vật, THE Game SHALL tăng Noise_Level thêm 20 điểm
5. WHEN Player chạy, THE Game SHALL tăng Noise_Level thêm 10 điểm mỗi giây
6. WHEN Player đi chậm, THE Game SHALL tăng Noise_Level thêm 2 điểm mỗi giây

### Yêu Cầu 4: Hành Vi Ma Quái

**User Story:** Là người chơi, tôi muốn ma có hành vi đe dọa và tuần tra, để tạo cảm giác căng thẳng và thử thách.

#### Tiêu Chí Chấp Nhận

1. THE Ghost SHALL tuần tra theo đường đi được định sẵn trên mỗi Floor
2. WHEN Noise_Level của Player vượt quá 30 và Player trong phạm vi 10 đơn vị, THE Ghost SHALL di chuyển về phía Player
3. WHEN Ghost phát hiện Player, THE Ghost SHALL truy đuổi Player
4. WHEN Ghost bắt được Player, THE Game SHALL kết thúc với trạng thái thua
5. THE Game SHALL tạo ít nhất 3 loại Ghost với tốc độ và phạm vi phát hiện khác nhau
6. WHILE Player ở trong Safe_Zone, THE Ghost SHALL không thể phát hiện hoặc tấn công Player

### Yêu Cầu 5: Tiếp Xúc Mắt

**User Story:** Là người chơi, tôi muốn tránh nhìn trực tiếp vào ma, để không bị phát hiện ngay lập tức.

#### Tiêu Chí Chấp Nhận

1. WHEN Player nhìn về hướng Ghost và Ghost trong tầm nhìn, THE Game SHALL thiết lập Eye_Contact
2. WHEN Eye_Contact xảy ra, THE Ghost SHALL ngay lập tức phát hiện Player
3. WHEN Eye_Contact xảy ra, THE Ghost SHALL bắt đầu truy đuổi Player
4. THE Game SHALL cung cấp chỉ báo hướng của Ghost mà không hiển thị trực tiếp Ghost
5. WHEN Player quay mặt đi, THE Game SHALL hủy Eye_Contact sau 1 giây

### Yêu Cầu 6: Khu Vực An Toàn

**User Story:** Là người chơi, tôi muốn có nơi ẩn náu tạm thời, để tránh ma khi bị truy đuổi.

#### Tiêu Chí Chấp Nhận

1. THE Game SHALL cung cấp 5 Safe_Zone: tủ đồ, phòng piano, phòng thể dục, khu bơi, và một vị trí bổ sung
2. WHEN Player vào Safe_Zone, THE Game SHALL đặt Noise_Level về 0
3. WHILE Player ở trong Safe_Zone, THE Ghost SHALL không thể phát hiện Player
4. WHILE Player ở trong Safe_Zone, THE Ghost SHALL tiếp tục tuần tra bình thường
5. THE Game SHALL cho phép Player rời khỏi Safe_Zone bất cứ lúc nào
6. WHEN Ghost đang truy đuổi và Player vào Safe_Zone, THE Ghost SHALL mất dấu Player sau 5 giây

### Yêu Cầu 7: Thánh Giá

**User Story:** Là người chơi, tôi muốn tìm và sử dụng thánh giá, để có thể tiêu diệt ma chính và thắng game.

#### Tiêu Chí Chấp Nhận

1. THE Game SHALL đặt Holy_Cross tại Spiritual_Club_Room
2. WHEN Player đến Spiritual_Club_Room, THE Game SHALL cho phép Player nhặt Holy_Cross
3. WHEN Player nhặt Holy_Cross, THE Game SHALL thêm Holy_Cross vào inventory của Player
4. WHEN Player có Holy_Cross và gặp Main_Ghost, THE Game SHALL cho phép Player sử dụng Holy_Cross
5. WHEN Player sử dụng Holy_Cross trên Main_Ghost, THE Game SHALL tiêu diệt Main_Ghost
6. WHEN Main_Ghost bị tiêu diệt, THE Game SHALL kết thúc với trạng thái thắng

### Yêu Cầu 8: Đường Thoát

**User Story:** Là người chơi, tôi muốn tìm đường thoát khỏi trường, để có thể thắng game bằng cách trốn thoát.

#### Tiêu Chí Chấp Nhận

1. THE Game SHALL cung cấp ít nhất một Escape_Route
2. WHEN Player tìm thấy Escape_Route, THE Game SHALL hiển thị tùy chọn thoát
3. WHEN Player sử dụng Escape_Route, THE Game SHALL kết thúc với trạng thái thắng
4. THE Game SHALL đặt Escape_Route ở vị trí khó tiếp cận hoặc yêu cầu khám phá
5. WHILE Ghost đang truy đuổi Player, THE Player SHALL vẫn có thể sử dụng Escape_Route

### Yêu Cầu 9: Điều Kiện Thắng Thua

**User Story:** Là người chơi, tôi muốn biết rõ điều kiện thắng và thua, để có mục tiêu rõ ràng khi chơi.

#### Tiêu Chí Chấp Nhận

1. WHEN Player sử dụng Escape_Route, THE Game SHALL kết thúc với trạng thái thắng
2. WHEN Player tiêu diệt Main_Ghost bằng Holy_Cross, THE Game SHALL kết thúc với trạng thái thắng
3. WHEN Ghost bắt được Player, THE Game SHALL kết thúc với trạng thái thua
4. WHEN game kết thúc, THE Game SHALL hiển thị màn hình kết quả với trạng thái thắng hoặc thua
5. WHEN game kết thúc, THE Game SHALL cung cấp tùy chọn chơi lại

### Yêu Cầu 10: Giao Diện Người Dùng

**User Story:** Là người chơi, tôi muốn có giao diện hiển thị thông tin quan trọng, để theo dõi trạng thái và đưa ra quyết định.

#### Tiêu Chí Chấp Nhận

1. THE Game SHALL hiển thị Floor hiện tại của Player
2. THE Game SHALL hiển thị Noise_Level hiện tại
3. WHEN Player có Holy_Cross, THE Game SHALL hiển thị biểu tượng Holy_Cross trong inventory
4. THE Game SHALL hiển thị chỉ báo hướng của Ghost gần nhất mà không hiển thị khoảng cách chính xác
5. THE Game SHALL hiển thị hướng dẫn điều khiển cơ bản
6. WHEN Player ở gần Safe_Zone, THE Game SHALL hiển thị chỉ báo có thể vào ẩn náu

### Yêu Cầu 11: Hệ Thống Tầng

**User Story:** Là người chơi, tôi muốn khám phá 5 tầng của trường học, để tìm kiếm vật phẩm và đường thoát.

#### Tiêu Chí Chấp Nhận

1. THE Game SHALL tạo 5 Floor với bố cục khác nhau
2. THE Game SHALL phân bổ Ghost khác nhau trên mỗi Floor
3. THE Game SHALL đặt Spiritual_Club_Room trên một trong các Floor
4. THE Game SHALL đặt các Safe_Zone trên các Floor khác nhau
5. WHEN Player di chuyển giữa các Floor, THE Game SHALL cập nhật vị trí và hiển thị Floor mới
6. THE Game SHALL đảm bảo mỗi Floor có ít nhất một đường đi đến Floor khác

### Yêu Cầu 12: Lưu và Tải Game

**User Story:** Là người chơi, tôi muốn lưu tiến trình, để có thể tiếp tục chơi sau này.

#### Tiêu Chí Chấp Nhận

1. WHEN người chơi chọn lưu game, THE Game SHALL lưu vị trí hiện tại của Player
2. WHEN người chơi chọn lưu game, THE Game SHALL lưu trạng thái của tất cả Ghost
3. WHEN người chơi chọn lưu game, THE Game SHALL lưu inventory của Player
4. WHEN người chơi chọn lưu game, THE Game SHALL lưu trạng thái của Holy_Cross
5. WHEN người chơi chọn tải game, THE Game SHALL khôi phục tất cả trạng thái đã lưu
6. IF việc lưu hoặc tải thất bại, THEN THE Game SHALL hiển thị thông báo lỗi rõ ràng
