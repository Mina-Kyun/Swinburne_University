# Tài Liệu Thiết Kế Kỹ Thuật - School Horror Survival Game

## Tổng Quan

Game School Horror Survival là một trò chơi kinh dị sinh tồn 3D góc nhìn thứ nhất (first-person), lấy bối cảnh trường học Nhật Bản về đêm. Người chơi điều khiển một học sinh nữ bị kẹt lại trong trường và phải tìm cách thoát ra trong khi tránh các thực thể ma quái.

### Mục Tiêu Thiết Kế

- **Stealth-focused gameplay**: Tập trung vào việc lén lút, quản lý tiếng động thay vì chiến đấu trực tiếp
- **Tension through mechanics**: Tạo căng thẳng thông qua cơ chế eye contact và noise detection
- **Multiple win conditions**: Cho phép người chơi thắng bằng cách thoát ra hoặc tiêu diệt ma chính
- **Exploration-driven**: Khuyến khích khám phá 5 tầng trường học để tìm vật phẩm và đường thoát

### Công Nghệ Đề Xuất

- **Game Engine**: Unity hoặc Godot (hỗ trợ 3D, physics, và cross-platform)
- **Ngôn ngữ**: C# (Unity) hoặc GDScript/C# (Godot)
- **Audio**: FMOD hoặc Wwise cho hệ thống âm thanh động
- **Lưu trữ**: JSON cho save/load system
- **Testing**: NUnit (Unity) hoặc GUT (Godot) cho unit tests, với property-based testing framework

## Kiến Trúc

### Kiến Trúc Tổng Thể

Game sử dụng kiến trúc **Component-Based Entity System** kết hợp với **MVC pattern** để tách biệt logic game, dữ liệu, và presentation.

```mermaid
graph TB
    subgraph "Presentation Layer"
        UI[UI Manager]
        Renderer[Rendering System]
        Audio[Audio Manager]
    end
    
    subgraph "Game Logic Layer"
        GM[Game Manager]
        PM[Player Manager]
        GhostM[Ghost Manager]
        NoiseM[Noise Manager]
        FloorM[Floor Manager]
    end
    
    subgraph "Data Layer"
        GameState[Game State]
        PlayerData[Player Data]
        GhostData[Ghost Data]
        LevelData[Level Data]
    end
    
    subgraph "Systems"
        Physics[Physics System]
        Collision[Collision System]
        SaveLoad[Save/Load System]
    end
    
    UI --> GM
    Renderer --> GM
    Audio --> NoiseM
    
    GM --> GameState
    PM --> PlayerData
    GhostM --> GhostData
    FloorM --> LevelData
    
    PM --> NoiseM
    GhostM --> NoiseM
    PM --> Collision
    GhostM --> Collision
    
    GM --> SaveLoad
    SaveLoad --> GameState
    SaveLoad --> PlayerData
    SaveLoad --> GhostData
```

### Luồng Xử Lý Chính

```mermaid
sequenceDiagram
    participant Player
    participant GameManager
    participant NoiseManager
    participant GhostManager
    participant CollisionSystem
    
    Player->>GameManager: Input (Move/Run/Crouch)
    GameManager->>NoiseManager: Update Noise Level
    NoiseManager->>GhostManager: Notify if Noise > Threshold
    GhostManager->>GhostManager: Update Ghost Behavior
    GhostManager->>CollisionSystem: Check Detection Range
    CollisionSystem->>GameManager: Report Collision/Detection
    GameManager->>Player: Update Game State
```

## Các Thành Phần và Giao Diện

### 1. Game Manager

**Trách nhiệm**: Quản lý vòng đời game, trạng thái tổng thể, và điều phối giữa các manager khác.

```csharp
interface IGameManager
{
    // Khởi tạo và vòng đời
    void InitializeGame();
    void StartGame();
    void PauseGame();
    void ResumeGame();
    void EndGame(GameResult result);
    
    // Trạng thái game
    GameState GetCurrentState();
    void SetGameState(GameState newState);
    
    // Điều kiện thắng/thua
    void CheckWinConditions();
    void TriggerGameOver(GameOverReason reason);
}

enum GameState
{
    MainMenu,
    Playing,
    Paused,
    GameOver,
    Victory
}

enum GameResult
{
    EscapeRoute,
    DefeatedMainGhost,
    CaughtByGhost
}
```

### 2. Player Manager

**Trách nhiệm**: Quản lý trạng thái, di chuyển, và tương tác của người chơi.

```csharp
interface IPlayerManager
{
    // Di chuyển
    void Move(Vector3 direction, MovementSpeed speed);
    void ChangeFloor(int targetFloor);
    void EnterRoom(Room room);
    
    // Tương tác
    void PickupItem(Item item);
    void UseItem(Item item);
    void EnterSafeZone(SafeZone zone);
    void ExitSafeZone();
    
    // Trạng thái
    Vector3 GetPosition();
    int GetCurrentFloor();
    float GetNoiseLevel();
    bool IsInSafeZone();
    Inventory GetInventory();
    
    // Góc nhìn
    Vector3 GetViewDirection();
    bool IsLookingAt(Ghost ghost);
}

enum MovementSpeed
{
    Crouch,  // Rón rén - Noise +2/s
    Walk,    // Đi bình thường - Noise +5/s
    Run      // Chạy - Noise +10/s
}
```

### 3. Ghost Manager

**Trách nhiệm**: Quản lý tất cả các thực thể ma, hành vi AI, và phát hiện người chơi.

```csharp
interface IGhostManager
{
    // Khởi tạo
    void SpawnGhosts(int count, GhostType[] types);
    Ghost GetMainGhost();
    List<Ghost> GetAllGhosts();
    
    // Cập nhật
    void UpdateGhostBehaviors(float deltaTime);
    void NotifyNoiseLevel(float noiseLevel, Vector3 sourcePosition);
    void NotifyEyeContact(Ghost ghost, Player player);
    
    // Phát hiện
    Ghost GetNearestGhost(Vector3 position);
    bool IsPlayerDetected(Player player);
    
    // Tiêu diệt
    void DestroyGhost(Ghost ghost);
}

interface IGhost
{
    // Thuộc tính
    GhostType GetGhostType();
    Vector3 GetPosition();
    GhostState GetState();
    
    // Hành vi
    void Patrol();
    void Investigate(Vector3 targetPosition);
    void Chase(Player player);
    void LoseTarget();
    
    // Phát hiện
    bool CanDetectPlayer(Player player, float noiseLevel);
    bool IsInDetectionRange(Vector3 position);
    float GetDetectionRadius();
    
    // Tương tác
    void CatchPlayer(Player player);
}

enum GhostType
{
    Slow,      // Chậm, phạm vi phát hiện nhỏ
    Normal,    // Tốc độ và phạm vi trung bình
    Fast,      // Nhanh, phạm vi phát hiện lớn
    MainGhost  // Ma chính, có thể bị tiêu diệt
}

enum GhostState
{
    Patrolling,
    Investigating,
    Chasing,
    Searching
}
```

### 4. Noise Manager

**Trách nhiệm**: Theo dõi và quản lý mức độ tiếng động của người chơi.

```csharp
interface INoiseManager
{
    // Cập nhật noise
    void UpdateNoise(float deltaTime);
    void AddNoise(float amount);
    void ResetNoise();
    void DecayNoise(float deltaTime);
    
    // Truy vấn
    float GetCurrentNoiseLevel();
    bool IsNoiseAboveThreshold(float threshold);
    
    // Sự kiện
    void OnPlayerMove(MovementSpeed speed);
    void OnPlayerCollision(Collision collision);
    void OnPlayerStandStill(float duration);
}

class NoiseConfig
{
    public const float MAX_NOISE = 100f;
    public const float DETECTION_THRESHOLD = 30f;
    public const float CROUCH_NOISE_RATE = 2f;
    public const float WALK_NOISE_RATE = 5f;
    public const float RUN_NOISE_RATE = 10f;
    public const float COLLISION_NOISE = 20f;
    public const float DECAY_TIME = 3f; // Giây đứng yên để noise về 0
}
```

### 5. Floor Manager

**Trách nhiệm**: Quản lý cấu trúc 5 tầng, phòng, và điểm di chuyển.

```csharp
interface IFloorManager
{
    // Khởi tạo
    void InitializeFloors();
    Floor GetFloor(int floorNumber);
    
    // Điều hướng
    List<Room> GetRoomsOnFloor(int floorNumber);
    List<Staircase> GetStaircases(int floorNumber);
    bool CanMoveBetweenFloors(int fromFloor, int toFloor);
    
    // Vị trí đặc biệt
    Room GetSpiritualClubRoom();
    List<SafeZone> GetSafeZones();
    List<EscapeRoute> GetEscapeRoutes();
}

interface IFloor
{
    int GetFloorNumber();
    List<Room> GetRooms();
    List<Staircase> GetStaircases();
    Vector3 GetSpawnPoint();
}

interface IRoom
{
    string GetRoomName();
    RoomType GetRoomType();
    Vector3 GetPosition();
    bool IsAccessible();
    List<Item> GetItems();
}

enum RoomType
{
    Library,
    SpiritualClub,
    Classroom,
    PianoRoom,
    Gym,
    SwimmingPool,
    Hallway,
    Staircase
}
```

### 6. Safe Zone Manager

**Trách nhiệm**: Quản lý các khu vực an toàn và tương tác với người chơi.

```csharp
interface ISafeZoneManager
{
    // Khởi tạo
    void InitializeSafeZones();
    List<SafeZone> GetAllSafeZones();
    
    // Tương tác
    SafeZone GetNearestSafeZone(Vector3 position);
    bool IsPlayerInSafeZone(Player player);
    void EnterSafeZone(Player player, SafeZone zone);
    void ExitSafeZone(Player player);
}

interface ISafeZone
{
    SafeZoneType GetZoneType();
    Vector3 GetPosition();
    int GetFloorNumber();
    bool IsOccupied();
    bool CanEnter();
    
    // Hiệu ứng
    void ApplySafetyEffect(Player player);
    void RemoveSafetyEffect(Player player);
}

enum SafeZoneType
{
    Locker,        // Tủ đồ
    PianoRoom,     // Phòng piano
    Gym,           // Phòng thể dục
    SwimmingPool,  // Khu bơi
    Additional     // Vị trí bổ sung
}
```

### 7. Item Manager

**Trách nhiệm**: Quản lý vật phẩm trong game, đặc biệt là Holy Cross.

```csharp
interface IItemManager
{
    // Khởi tạo
    void InitializeItems();
    void PlaceHolyCross(Room spiritualClubRoom);
    
    // Tương tác
    Item GetItemAt(Vector3 position);
    bool CanPickup(Item item, Player player);
    void PickupItem(Item item, Player player);
    void UseItem(Item item, Player player, Ghost target);
}

interface IItem
{
    ItemType GetItemType();
    string GetName();
    Vector3 GetPosition();
    bool IsCollected();
    
    void OnPickup(Player player);
    void OnUse(Player player, Ghost target);
}

enum ItemType
{
    HolyCross,
    Key,
    Note
}
```

### 8. Save/Load System

**Trách nhiệm**: Lưu và tải trạng thái game.

```csharp
interface ISaveLoadSystem
{
    // Lưu
    bool SaveGame(string saveSlot);
    SaveData CreateSaveData();
    
    // Tải
    bool LoadGame(string saveSlot);
    bool HasSaveData(string saveSlot);
    
    // Quản lý
    List<string> GetSaveSlots();
    void DeleteSave(string saveSlot);
}

class SaveData
{
    // Player data
    public Vector3 PlayerPosition;
    public int CurrentFloor;
    public List<string> Inventory;
    public float NoiseLevel;
    
    // Ghost data
    public List<GhostSaveData> Ghosts;
    public bool MainGhostDefeated;
    
    // World state
    public List<string> CollectedItems;
    public float PlayTime;
    public DateTime SaveTime;
}
```

### 9. UI Manager

**Trách nhiệm**: Quản lý giao diện người dùng và hiển thị thông tin.

```csharp
interface IUIManager
{
    // HUD
    void UpdateFloorDisplay(int floor);
    void UpdateNoiseLevel(float noiseLevel);
    void UpdateInventory(Inventory inventory);
    void ShowGhostDirectionIndicator(Vector3 ghostDirection);
    void ShowSafeZonePrompt(SafeZone zone);
    
    // Màn hình
    void ShowMainMenu();
    void ShowPauseMenu();
    void ShowGameOverScreen(GameResult result);
    void ShowVictoryScreen(GameResult result);
    
    // Hướng dẫn
    void ShowControls();
    void ShowTutorial();
}
```

## Mô Hình Dữ Liệu

### Player Data Model

```csharp
class PlayerData
{
    // Vị trí và di chuyển
    public Vector3 Position { get; set; }
    public Vector3 ViewDirection { get; set; }
    public int CurrentFloor { get; set; }
    public MovementSpeed CurrentSpeed { get; set; }
    
    // Trạng thái
    public float NoiseLevel { get; set; }
    public bool IsInSafeZone { get; set; }
    public SafeZone CurrentSafeZone { get; set; }
    
    // Inventory
    public Inventory Inventory { get; set; }
    
    // Thời gian
    public float StandStillTime { get; set; }
    
    // Invariants
    public bool IsValid()
    {
        return NoiseLevel >= 0 && NoiseLevel <= 100 &&
               CurrentFloor >= 1 && CurrentFloor <= 5 &&
               (IsInSafeZone == (CurrentSafeZone != null));
    }
}

class Inventory
{
    private List<Item> items;
    public const int MAX_ITEMS = 10;
    
    public bool HasHolyCross { get; set; }
    public List<Item> Items => items;
    
    public bool CanAddItem() => items.Count < MAX_ITEMS;
    public void AddItem(Item item) { /* ... */ }
    public void RemoveItem(Item item) { /* ... */ }
}
```

### Ghost Data Model

```csharp
class GhostData
{
    // Định danh
    public string GhostId { get; set; }
    public GhostType Type { get; set; }
    public bool IsMainGhost { get; set; }
    
    // Vị trí và di chuyển
    public Vector3 Position { get; set; }
    public int CurrentFloor { get; set; }
    public List<Vector3> PatrolPath { get; set; }
    public int CurrentPatrolIndex { get; set; }
    
    // Trạng thái
    public GhostState State { get; set; }
    public Vector3 TargetPosition { get; set; }
    public float ChaseTimer { get; set; }
    
    // Thuộc tính
    public float MovementSpeed { get; set; }
    public float DetectionRadius { get; set; }
    public bool IsDefeated { get; set; }
    
    // Invariants
    public bool IsValid()
    {
        return CurrentFloor >= 1 && CurrentFloor <= 5 &&
               DetectionRadius > 0 &&
               MovementSpeed > 0 &&
               (!IsDefeated || IsMainGhost);
    }
}
```

### Floor Data Model

```csharp
class FloorData
{
    public int FloorNumber { get; set; }
    public List<Room> Rooms { get; set; }
    public List<Staircase> Staircases { get; set; }
    public Vector3 SpawnPoint { get; set; }
    
    // Layout
    public float Width { get; set; }
    public float Length { get; set; }
    
    // Invariants
    public bool IsValid()
    {
        return FloorNumber >= 1 && FloorNumber <= 5 &&
               Rooms != null && Rooms.Count > 0 &&
               Staircases != null;
    }
}

class Room
{
    public string RoomId { get; set; }
    public string RoomName { get; set; }
    public RoomType Type { get; set; }
    public Vector3 Position { get; set; }
    public Vector3 Size { get; set; }
    public bool IsAccessible { get; set; }
    public List<Item> Items { get; set; }
}

class Staircase
{
    public int FromFloor { get; set; }
    public int ToFloor { get; set; }
    public Vector3 Position { get; set; }
    public bool IsAccessible { get; set; }
    
    public bool IsValid()
    {
        return Math.Abs(FromFloor - ToFloor) == 1 &&
               FromFloor >= 1 && FromFloor <= 5 &&
               ToFloor >= 1 && ToFloor <= 5;
    }
}
```

### Game State Model

```csharp
class GameStateData
{
    // Trạng thái tổng thể
    public GameState CurrentState { get; set; }
    public float GameTime { get; set; }
    
    // Tham chiếu
    public PlayerData Player { get; set; }
    public List<GhostData> Ghosts { get; set; }
    public List<FloorData> Floors { get; set; }
    
    // Tiến trình
    public bool HolyCrossCollected { get; set; }
    public bool MainGhostDefeated { get; set; }
    public bool EscapeRouteFound { get; set; }
    
    // Kết quả
    public GameResult? Result { get; set; }
    
    // Invariants
    public bool IsValid()
    {
        return Player != null && Player.IsValid() &&
               Ghosts != null && Ghosts.All(g => g.IsValid()) &&
               Floors != null && Floors.Count == 5 &&
               Floors.All(f => f.IsValid());
    }
}
```

### Safe Zone Data Model

```csharp
class SafeZoneData
{
    public string ZoneId { get; set; }
    public SafeZoneType Type { get; set; }
    public Vector3 Position { get; set; }
    public int FloorNumber { get; set; }
    public bool IsOccupied { get; set; }
    public float Radius { get; set; }
    
    public bool IsValid()
    {
        return FloorNumber >= 1 && FloorNumber <= 5 &&
               Radius > 0;
    }
}
```



## Correctness Properties

*Property (thuộc tính) là một đặc điểm hoặc hành vi phải đúng trong tất cả các lần thực thi hợp lệ của hệ thống - về cơ bản, đó là một phát biểu chính thức về những gì hệ thống nên làm. Properties đóng vai trò là cầu nối giữa các đặc tả có thể đọc được bởi con người và các đảm bảo tính đúng đắn có thể xác minh được bằng máy.*

### Property 1: Khởi Tạo Game Đầy Đủ

*For any* lần khởi động game, hệ thống phải tạo đầy đủ các thành phần: ít nhất 3 loại Ghost khác nhau, ít nhất một Escape_Route, và đảm bảo tất cả 5 Floor được khởi tạo với connectivity.

**Validates: Requirements 1.2, 1.5, 11.1, 11.6**

### Property 2: Noise Level Invariant

*For any* thao tác trong game (di chuyển, va chạm, đứng yên, vào safe zone), Noise_Level của Player phải luôn nằm trong khoảng [0, 100].

**Validates: Requirements 3.1**

### Property 3: Noise Increase on Movement

*For any* trạng thái di chuyển (chạy, đi bộ, rón rén), Noise_Level phải tăng theo tốc độ tương ứng: chạy (+10/s) > đi bộ (+5/s) > rón rén (+2/s).

**Validates: Requirements 2.2, 2.3, 3.5, 3.6**

### Property 4: Noise Decay

*For any* trạng thái Player đứng yên, sau 3 giây Noise_Level phải giảm về 0.

**Validates: Requirements 3.3**

### Property 5: Collision Noise

*For any* va chạm giữa Player và vật thể, Noise_Level phải tăng thêm 20 điểm (không vượt quá 100).

**Validates: Requirements 2.6, 3.4**

### Property 6: Movement Direction

*For any* input di chuyển hợp lệ, Player phải di chuyển theo hướng được chỉ định và vị trí mới phải khác vị trí cũ.

**Validates: Requirements 2.1**

### Property 7: Floor Navigation

*For any* cầu thang kết nối hai Floor, Player phải có thể di chuyển giữa hai Floor đó, và sau khi di chuyển, CurrentFloor của Player phải được cập nhật chính xác.

**Validates: Requirements 2.4, 11.5**

### Property 8: Room Accessibility

*For any* phòng có cửa mở (IsAccessible = true), Player phải có thể vào phòng đó.

**Validates: Requirements 2.5**

### Property 9: Ghost Detection by Noise

*For any* Ghost, khi Noise_Level > 30 và khoảng cách giữa Player và Ghost < 10 đơn vị, Ghost phải di chuyển về phía Player (chuyển sang trạng thái Investigating hoặc Chasing).

**Validates: Requirements 3.2, 4.2**

### Property 10: Ghost Patrol Behavior

*For any* Ghost ở trạng thái Patrolling, Ghost phải di chuyển theo PatrolPath được định sẵn và quay lại điểm đầu khi đến điểm cuối.

**Validates: Requirements 4.1**

### Property 11: Ghost Chase on Detection

*For any* Ghost phát hiện Player (qua noise, eye contact, hoặc line of sight), Ghost phải chuyển sang trạng thái Chasing và di chuyển về phía Player.

**Validates: Requirements 4.3**

### Property 12: Game Over on Caught

*For any* trường hợp Ghost bắt được Player (khoảng cách < threshold), game phải kết thúc với GameState = GameOver và GameResult = CaughtByGhost.

**Validates: Requirements 4.4**

### Property 13: Safe Zone Protection

*For any* Player ở trong Safe_Zone, không có Ghost nào có thể phát hiện hoặc tấn công Player, bất kể Noise_Level hay Eye_Contact.

**Validates: Requirements 4.6, 6.3**

### Property 14: Safe Zone Noise Reset

*For any* lần Player vào Safe_Zone, Noise_Level phải được đặt về 0 ngay lập tức.

**Validates: Requirements 6.2**

### Property 15: Ghost Behavior Independence in Safe Zone

*For any* Ghost, khi Player ở trong Safe_Zone, Ghost phải tiếp tục hành vi tuần tra bình thường (không bị ảnh hưởng bởi Player).

**Validates: Requirements 6.4**

### Property 16: Safe Zone Exit Freedom

*For any* thời điểm Player ở trong Safe_Zone, Player phải có thể rời khỏi Safe_Zone (không bị khóa).

**Validates: Requirements 6.5**

### Property 17: Ghost Lose Target in Safe Zone

*For any* Ghost đang ở trạng thái Chasing, khi Player vào Safe_Zone và ở trong đó ít nhất 5 giây, Ghost phải chuyển về trạng thái Patrolling hoặc Searching.

**Validates: Requirements 6.6**

### Property 18: Eye Contact Detection

*For any* trường hợp Player nhìn về hướng Ghost (góc nhìn < threshold) và Ghost trong tầm nhìn (không bị vật cản), hệ thống phải thiết lập Eye_Contact = true.

**Validates: Requirements 5.1**

### Property 19: Eye Contact Immediate Detection

*For any* lần Eye_Contact được thiết lập, Ghost phải ngay lập tức phát hiện Player và chuyển sang trạng thái Chasing.

**Validates: Requirements 5.2, 5.3**

### Property 20: Eye Contact Break

*For any* trạng thái Eye_Contact = true, khi Player quay mặt đi (không nhìn vào Ghost) trong ít nhất 1 giây, Eye_Contact phải được đặt về false.

**Validates: Requirements 5.5**

### Property 21: Holy Cross Pickup

*For any* lần Player đến Spiritual_Club_Room và tương tác với Holy_Cross, Holy_Cross phải được thêm vào Inventory của Player và HasHolyCross phải = true.

**Validates: Requirements 7.2, 7.3**

### Property 22: Holy Cross Usage Condition

*For any* trường hợp Player có Holy_Cross (HasHolyCross = true) và gặp Main_Ghost trong phạm vi sử dụng, Player phải có thể sử dụng Holy_Cross.

**Validates: Requirements 7.4**

### Property 23: Main Ghost Defeat

*For any* lần Player sử dụng Holy_Cross trên Main_Ghost, Main_Ghost phải bị tiêu diệt (IsDefeated = true) và game phải kết thúc với GameState = Victory và GameResult = DefeatedMainGhost.

**Validates: Requirements 7.5, 7.6**

### Property 24: Escape Route Usage

*For any* lần Player tìm thấy và sử dụng Escape_Route, game phải kết thúc với GameState = Victory và GameResult = EscapeRoute, bất kể có Ghost đang truy đuổi hay không.

**Validates: Requirements 8.2, 8.3, 8.5**

### Property 25: Game End Screen

*For any* lần game kết thúc (GameState = GameOver hoặc Victory), hệ thống phải hiển thị màn hình kết quả với GameResult tương ứng và cung cấp tùy chọn chơi lại.

**Validates: Requirements 9.4, 9.5**

### Property 26: UI State Synchronization

*For any* thay đổi trong game state (Floor, Noise_Level, Inventory), UI phải được cập nhật để phản ánh đúng trạng thái hiện tại.

**Validates: Requirements 10.1, 10.2, 10.3, 10.6**

### Property 27: Ghost Distribution

*For any* lần khởi tạo game, Ghost phải được phân bổ trên nhiều Floor khác nhau (không tập trung tất cả trên một Floor).

**Validates: Requirements 11.2**

### Property 28: Spiritual Club Room Existence

*For any* lần khởi tạo game, phải tồn tại đúng một Spiritual_Club_Room trên một trong 5 Floor.

**Validates: Requirements 11.3**

### Property 29: Safe Zone Distribution

*For any* lần khởi tạo game, 5 Safe_Zone phải được phân bổ trên các Floor khác nhau (không tập trung tất cả trên một Floor).

**Validates: Requirements 11.4**

### Property 30: Save/Load Round Trip

*For any* trạng thái game hợp lệ, thực hiện Save rồi Load phải khôi phục lại chính xác trạng thái đó (vị trí Player, trạng thái Ghost, Inventory, Holy_Cross status).

**Validates: Requirements 12.1, 12.2, 12.3, 12.4, 12.5**

## Xử Lý Lỗi

### 1. Lỗi Khởi Tạo

**Tình huống**: Không thể tạo đủ Ghost, Floor, hoặc Safe_Zone khi khởi động game.

**Xử lý**:
- Log chi tiết lỗi vào console/file
- Hiển thị thông báo lỗi cho người chơi: "Không thể khởi tạo game. Vui lòng thử lại."
- Quay về Main Menu
- Không cho phép bắt đầu game với trạng thái không đầy đủ

**Validation**: Kiểm tra `GameStateData.IsValid()` sau khởi tạo

### 2. Lỗi Di Chuyển

**Tình huống**: Player cố gắng di chuyển đến vị trí không hợp lệ (ngoài bounds, vào tường, v.v.)

**Xử lý**:
- Giữ Player ở vị trí hiện tại
- Không tăng Noise_Level
- Log warning nếu xảy ra thường xuyên (có thể là bug collision detection)
- Không crash game

**Validation**: Kiểm tra collision trước khi cập nhật vị trí

### 3. Lỗi Ghost AI

**Tình huống**: Ghost không thể tìm đường đến Player hoặc patrol path không hợp lệ.

**Xử lý**:
- Ghost chuyển về trạng thái Patrolling
- Nếu patrol path không hợp lệ, Ghost đứng yên tại vị trí hiện tại
- Log warning để debug
- Không crash game hoặc làm game unplayable

**Validation**: Validate patrol path khi khởi tạo Ghost

### 4. Lỗi Save/Load

**Tình huống**: Không thể lưu game (disk full, permission denied) hoặc file save bị corrupt.

**Xử lý**:
- **Khi Save thất bại**:
  - Hiển thị thông báo: "Không thể lưu game. Kiểm tra dung lượng ổ đĩa."
  - Không ghi đè file save cũ (nếu có)
  - Log chi tiết lỗi
  
- **Khi Load thất bại**:
  - Hiển thị thông báo: "File save bị lỗi hoặc không tồn tại."
  - Cung cấp tùy chọn: "Bắt đầu game mới" hoặc "Quay lại menu"
  - Không crash game

**Validation**: 
- Validate SaveData structure trước khi deserialize
- Sử dụng try-catch cho file I/O operations
- Implement checksum để phát hiện file corrupt

### 5. Lỗi Item Interaction

**Tình huống**: Player cố gắng sử dụng Holy_Cross khi không có hoặc không đúng target.

**Xử lý**:
- Kiểm tra điều kiện trước khi cho phép sử dụng
- Nếu không hợp lệ, không thực hiện action và hiển thị feedback nhẹ
- Không hiển thị error message (để tránh phá vỡ immersion)

**Validation**: Kiểm tra `Inventory.HasHolyCross` và `Ghost.IsMainGhost` trước khi sử dụng

### 6. Lỗi State Transition

**Tình huống**: Game state chuyển đổi không hợp lệ (ví dụ: từ GameOver về Playing mà không reset).

**Xử lý**:
- Validate state transition trước khi thực hiện
- Log error nếu transition không hợp lệ
- Giữ nguyên state hiện tại
- Trong trường hợp nghiêm trọng, reset về Main Menu

**Validation**: Implement state machine với valid transitions

### 7. Lỗi Noise Level

**Tình huống**: Noise_Level vượt quá giới hạn [0, 100] do bug tính toán.

**Xử lý**:
- Clamp giá trị về [0, 100] ngay lập tức
- Log warning để debug
- Tiếp tục game bình thường

**Validation**: Luôn clamp sau mỗi lần cập nhật Noise_Level

### 8. Lỗi Collision Detection

**Tình huống**: Ghost và Player overlap nhưng không trigger catch event.

**Xử lý**:
- Implement backup collision check mỗi frame
- Nếu phát hiện overlap, trigger catch ngay lập tức
- Log error để fix collision system

**Validation**: Double-check collision trong update loop

### 9. Lỗi Floor Navigation

**Tình huống**: Player cố gắng chuyển Floor nhưng không có cầu thang kết nối.

**Xử lý**:
- Không cho phép chuyển Floor
- Giữ Player ở Floor hiện tại
- Không hiển thị error (người chơi sẽ tự hiểu không có đường đi)

**Validation**: Kiểm tra `FloorManager.CanMoveBetweenFloors()` trước khi chuyển

### 10. Lỗi Safe Zone

**Tình huống**: Player trong Safe_Zone nhưng vẫn bị Ghost phát hiện (bug).

**Xử lý**:
- Force Ghost về trạng thái Patrolling
- Đảm bảo Player không bị tấn công
- Log error để fix detection logic
- Ưu tiên bảo vệ player experience

**Validation**: Kiểm tra `Player.IsInSafeZone` trước mọi detection check

## Chiến Lược Testing

### Dual Testing Approach

Game sẽ được test bằng cả **Unit Testing** và **Property-Based Testing** để đảm bảo tính đúng đắn toàn diện:

- **Unit Tests**: Kiểm tra các ví dụ cụ thể, edge cases, và error conditions
- **Property Tests**: Xác minh các thuộc tính phổ quát trên nhiều input ngẫu nhiên
- Cả hai phương pháp bổ trợ cho nhau: Unit tests bắt lỗi cụ thể, Property tests xác minh tính đúng đắn tổng quát

### Property-Based Testing Configuration

**Framework**: 
- Unity: [QuickCheck for Unity](https://github.com/silentorb/QuickCheck) hoặc tự implement với NUnit
- Godot: [GdUnit4](https://github.com/MikeSchulze/gdUnit4) với property testing extension

**Configuration**:
- Mỗi property test chạy tối thiểu **100 iterations** (do tính ngẫu nhiên)
- Mỗi test phải reference property tương ứng trong design document
- Tag format: `// Feature: school-horror-survival-game, Property {number}: {property_text}`

### Unit Testing Strategy

**Test Coverage**:
- Core mechanics: Movement, Noise system, Ghost AI, Safe zones
- Game state transitions: Playing → GameOver, Playing → Victory
- Item interactions: Pickup, Use Holy Cross
- Save/Load functionality
- UI updates

**Test Organization**:
```
Tests/
├── Unit/
│   ├── PlayerTests.cs
│   ├── GhostTests.cs
│   ├── NoiseManagerTests.cs
│   ├── SafeZoneTests.cs
│   ├── ItemManagerTests.cs
│   ├── SaveLoadTests.cs
│   └── GameManagerTests.cs
├── Property/
│   ├── MovementProperties.cs
│   ├── NoiseProperties.cs
│   ├── GhostBehaviorProperties.cs
│   ├── SafeZoneProperties.cs
│   ├── GameStateProperties.cs
│   └── SaveLoadProperties.cs
└── Integration/
    ├── GameFlowTests.cs
    └── EndToEndTests.cs
```

### Property Test Examples

**Example 1: Noise Level Invariant (Property 2)**
```csharp
// Feature: school-horror-survival-game, Property 2: Noise Level Invariant
[Test]
public void NoiseLevel_AlwaysWithinBounds_ForAnyOperation()
{
    QuickCheck.ForAll(
        Gen.Float(0, 100),  // Initial noise
        Gen.Enum<MovementSpeed>(),  // Movement type
        Gen.Float(0, 10),  // Duration
        (initialNoise, speed, duration) =>
        {
            var player = new Player { NoiseLevel = initialNoise };
            var noiseManager = new NoiseManager(player);
            
            // Perform various operations
            noiseManager.OnPlayerMove(speed);
            noiseManager.UpdateNoise(duration);
            
            // Property: Noise must always be in [0, 100]
            Assert.That(player.NoiseLevel, Is.InRange(0f, 100f));
        },
        iterations: 100
    );
}
```

**Example 2: Save/Load Round Trip (Property 30)**
```csharp
// Feature: school-horror-survival-game, Property 30: Save/Load Round Trip
[Test]
public void SaveLoad_PreservesGameState_ForAnyValidState()
{
    QuickCheck.ForAll(
        GenerateRandomGameState(),
        (gameState) =>
        {
            var saveSystem = new SaveLoadSystem();
            
            // Save
            var saveData = saveSystem.CreateSaveData(gameState);
            var json = JsonUtility.ToJson(saveData);
            
            // Load
            var loadedData = JsonUtility.FromJson<SaveData>(json);
            var loadedState = saveSystem.RestoreGameState(loadedData);
            
            // Property: Loaded state must equal original state
            Assert.That(loadedState.Player.Position, 
                       Is.EqualTo(gameState.Player.Position));
            Assert.That(loadedState.Player.CurrentFloor, 
                       Is.EqualTo(gameState.Player.CurrentFloor));
            Assert.That(loadedState.Player.Inventory.HasHolyCross, 
                       Is.EqualTo(gameState.Player.Inventory.HasHolyCross));
            Assert.That(loadedState.Ghosts.Count, 
                       Is.EqualTo(gameState.Ghosts.Count));
        },
        iterations: 100
    );
}
```

### Unit Test Examples

**Example 1: Specific Initialization**
```csharp
[Test]
public void GameInitialization_PlacesPlayerInLibraryFloor5()
{
    var gameManager = new GameManager();
    gameManager.InitializeGame();
    
    var player = gameManager.GetPlayer();
    
    Assert.That(player.CurrentFloor, Is.EqualTo(5));
    Assert.That(player.GetCurrentRoom().RoomType, Is.EqualTo(RoomType.Library));
}
```

**Example 2: Holy Cross Placement**
```csharp
[Test]
public void GameInitialization_PlacesHolyCrossInSpiritualClubRoom()
{
    var gameManager = new GameManager();
    gameManager.InitializeGame();
    
    var spiritualClubRoom = gameManager.FloorManager.GetSpiritualClubRoom();
    var holyCross = spiritualClubRoom.GetItems()
        .FirstOrDefault(item => item.GetItemType() == ItemType.HolyCross);
    
    Assert.That(holyCross, Is.Not.Null);
}
```

**Example 3: Edge Case - Noise at Maximum**
```csharp
[Test]
public void NoiseManager_ClampsToMaximum_WhenExceedingLimit()
{
    var player = new Player { NoiseLevel = 95f };
    var noiseManager = new NoiseManager(player);
    
    // Add noise that would exceed 100
    noiseManager.AddNoise(20f);
    
    Assert.That(player.NoiseLevel, Is.EqualTo(100f));
}
```

**Example 4: Error Handling - Save Failure**
```csharp
[Test]
public void SaveSystem_ReturnsError_WhenDiskFull()
{
    var saveSystem = new SaveLoadSystem();
    var gameState = CreateTestGameState();
    
    // Mock disk full scenario
    MockFileSystem.SimulateDiskFull();
    
    var result = saveSystem.SaveGame("slot1");
    
    Assert.That(result, Is.False);
    Assert.That(saveSystem.GetLastError(), 
               Contains.Substring("Không thể lưu game"));
}
```

### Integration Testing

**Scenarios to Test**:
1. Complete game flow: Start → Explore → Find Holy Cross → Defeat Main Ghost → Victory
2. Complete game flow: Start → Explore → Find Escape Route → Escape → Victory
3. Failure flow: Start → Explore → Caught by Ghost → Game Over
4. Safe zone usage: Being chased → Enter safe zone → Ghost loses target
5. Eye contact: Look at ghost → Immediate chase → Look away → Break contact

### Performance Testing

**Metrics to Monitor**:
- Frame rate: Maintain 60 FPS on target hardware
- Ghost AI update time: < 5ms per frame for all ghosts
- Collision detection: < 2ms per frame
- Save/Load time: < 1 second for typical save file
- Memory usage: < 500MB on target platform

### Test Automation

**CI/CD Pipeline**:
1. Run all unit tests on every commit
2. Run property tests on every pull request
3. Run integration tests nightly
4. Generate coverage report (target: >80% for core logic)
5. Performance benchmarks weekly

**Test Data Generation**:
- Use seed-based random generation for reproducibility
- Generate diverse game states for property testing
- Include edge cases: empty floors, maximum ghosts, full inventory

### Manual Testing Checklist

**Gameplay Feel**:
- [ ] Movement feels responsive
- [ ] Ghost behavior is threatening but fair
- [ ] Safe zones provide relief
- [ ] Noise system creates tension
- [ ] Eye contact mechanic is clear

**Balance**:
- [ ] Game is completable within reasonable time
- [ ] Difficulty curve is appropriate
- [ ] Multiple strategies are viable

**Polish**:
- [ ] UI is readable and informative
- [ ] Audio cues are helpful
- [ ] No game-breaking bugs
- [ ] Save/Load works reliably
