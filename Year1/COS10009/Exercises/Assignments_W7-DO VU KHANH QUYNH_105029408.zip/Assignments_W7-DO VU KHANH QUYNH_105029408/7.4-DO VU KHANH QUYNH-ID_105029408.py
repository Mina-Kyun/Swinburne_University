import input_functions as input_function

class Rent:
    def __init__(self, room_ID: str, room_price: float):
        # Basic Information
        self.room_ID = room_ID
        self.room_price = room_price
        # Utilities (for calculation)
        self.elec_usage = 0.0
        self.water_usage = 0.0
        # Separate services
        self.parking_fee = 0.0
        self.wifi_fee = 0.0
        self.elevator_fee = 100000.0
        self.trash_fee = 20000.0
        self.laundry_fee = 100000.0

    def input_data(self):
        print(f"Enter data for the room: {self.room_ID}")
        self.elec_usage = input_function.read_float("Enter the electicity consumption (kWh): ")
        self.water_usage = input_function.read_float("Enter the volume of water consumed:")

    def calculate_total(self):
        self.total_elec = self.elec_usage * 3500.0
        self.total_water = self.water_usage * 20000.0
        total = (self.room_price + self.total_elec + self.total_water + self.parking_fee + self.wifi_fee +
                self.elevator_fee + self.trash_fee + self.laundry_fee)
        return total

    def display_bill(self):
        total = self.calculate_total()
        print(f"\nRECEIPT ROOM: {self.room_ID}")
        print(f"- Room rate: {self.room_price}")
        print(f"- Electricity cost: {self.total_elec}")
        print(f"- Water cost: {self.total_water}")
        print(f"TOTAL: {total} VND")

def main():
    room_info = Rent("101", 3500000.0)
    room_info.input_data()
    room_info.display_bill()

if __name__ == "__main__":
    main()
