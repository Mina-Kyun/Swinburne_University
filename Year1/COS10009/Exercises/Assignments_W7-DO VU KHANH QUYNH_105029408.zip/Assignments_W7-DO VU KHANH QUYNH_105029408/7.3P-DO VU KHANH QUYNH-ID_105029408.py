import input_functions
# Task 6.1 T - use the code from 5.1 to help with this

class Track:
    def __init__(self, name, location):
        self.name = name
        self.location = location

# Reads in and returns a single track from the given file
def read_track(music_file):
    name = music_file.readline().strip()
    location = music_file.readline().strip()
    return Track(name, location)

# Returns an array of tracks read from the given file
def read_tracks(music_file):
    count = int(music_file.readline())
    tracks = []
    i = 0
    while i < count:
        track = read_track(music_file)
        tracks.append(track)
        i += 1
    return tracks

 # print all the tracks use tracks[x] to access each track
# Replace with your code
def print_tracks(tracks):
    i = 0
    while i < len(tracks):
        print_track(tracks[i])
        i += 1

# search for track by name
def print_track(track):
    print(f"Track title is: {track.name}")
    print(f"Track file location is: {track.location}")

# returns the index of the track or -1 if not found
def search_for_track_name(tracks, search_string):
    i = 0
    while i < len(tracks):
        if tracks[i].name.strip().lower() == search_string.strip().lower():
            return i
        i += 1
    return -1

def main():
    # Open the file using "with" to ensure it gets closed later
    with open("album.txt", "r") as music_file:
        tracks = read_tracks(music_file)
        print_tracks(tracks)

    search_string = input_functions.read_string("Enter the track name you wish to find: ")
    index = search_for_track_name(tracks, search_string)
    if index > -1:
        print(f"Found {tracks[index].name} at index {index}")
    else:
        print("Entry not found")

if __name__ == "__main__":
    main()