def search_value(data, val):
    i = 0
    result = False
    while i < len(data):
        if data[i] == val:
            result = True
            return result
        i += 1
    return result
data1 = [2, 6, -4, 3, 7]
val1 = 3
result1 = search_value(data1, val1)
print(f"Result for data1 (searching for {val1}): {result1}")
data2 = [-2, 8, 2, -5, 9]
val2 = 6
result2 = search_value(data2, val2)
print(f"Result for data2 (searching for {val2}): {result2}")