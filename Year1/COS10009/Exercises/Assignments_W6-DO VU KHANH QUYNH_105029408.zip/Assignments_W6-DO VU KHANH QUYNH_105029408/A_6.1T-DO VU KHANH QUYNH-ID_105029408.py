def Sum_Function(Data):
    result = 0
    i = 0
    while i < len(Data):
        result += Data[i]
        i += 1
    return result
data1 = [6, -3, 3, 8, 1]
print("Results of dataset 1:", Sum_Function(data1))
data2 = [2, 6, -2, 3]
print("Results of dataset 2:", Sum_Function(data2))