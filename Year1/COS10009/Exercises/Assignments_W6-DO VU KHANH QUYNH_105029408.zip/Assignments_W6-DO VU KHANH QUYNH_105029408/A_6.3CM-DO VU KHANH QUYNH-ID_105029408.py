import math
import random
import pygame
from math import pi as PI

# Initialize Pygame
pygame.init()
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Pygame Shapes")
clock = pygame.time.Clock()
 
"""
Define colors as constants for better readability.
Colors are defined using RGB values.
"""
WHITE = (255, 255, 255) 
BLACK = (0, 0, 0) # for sky
YELLOW = (255, 255, 0) # for star
RED = (255, 0, 0)  # design
SKY_BLUE = (135, 206, 235) # design
GREEN = (0, 255, 0) # for garden
BLUE = (0, 0, 255) # for pool
MAROON = (128, 0, 0) # for street
SEA_GREEN = (46, 139, 87) # for house
PURPLE = (128, 0, 128) # for window
GRAY = (96,96,96) # for window
YELLOW_CENTER = (255, 255, 0) # for window
WINE_RED = (128, 0, 32) # for roof
ORANGE = (255, 165, 0) # for dog
PINK = (255, 182, 193) # for flower
DARK_GREEN = (0, 100, 0) # for leaves
BROWN = (101, 67, 33) #for the trunk
D_GREEN = (0, 204, 0) # for fish
BLUE_GRAY = (63,95,77) # for staircase
DARK_BLUE_GRAY = (64,84,73) # for staircase
'''
screen
align and divide the number of squares for drawing
'''
# Fill the background with black
screen.fill(BLACK)
# Each square measures 12 pixels to fit a screen with a height of 600px
SCALE = 9
# The distance to swipe right (towards the center of the screen)
OFFSET = 150

'''
Draw the road
The winding turns
add color to the road
'''
# Point on the left of the road (Use polygons to change color)
road_points = [
    (15*SCALE + OFFSET, 45*SCALE), (10*SCALE + OFFSET, 40*SCALE), (20*SCALE + OFFSET, 30*SCALE), (16*SCALE + OFFSET, 25*SCALE), (16*SCALE + OFFSET, 22*SCALE), # Lề trái đi lên
    (19*SCALE + OFFSET, 22*SCALE), (19*SCALE + OFFSET, 25*SCALE), (25*SCALE + OFFSET, 30*SCALE), (15*SCALE + OFFSET, 40*SCALE), (20*SCALE + OFFSET, 45*SCALE)  # Lề phải đi xuống
]
# Draw the gray path
pygame.draw.polygon(screen, GRAY, road_points)
# Add more maroon outlines to match the sketch
pygame.draw.lines(screen, MAROON, False, road_points[:5], 3) # Left border
pygame.draw.lines(screen, MAROON, False, road_points[5:], 3) # Right border

'''
Draw a staircase
create a focal point through color and steps
'''
# Step 1 (The longest step - located at the top)
step1_points = [
    (14*SCALE + OFFSET, 21*SCALE), (14*SCALE + OFFSET, 20*SCALE), 
    (21*SCALE + OFFSET, 20*SCALE), (21*SCALE + OFFSET, 21*SCALE)
]
# Level 2 (Lower level - connected to the road)
step2_points = [
    (15*SCALE + OFFSET, 22*SCALE), (15*SCALE + OFFSET, 21*SCALE), 
    (20*SCALE + OFFSET, 21*SCALE), (20*SCALE + OFFSET, 22*SCALE)
]
# Color the steps (blue-gray).
pygame.draw.polygon(screen, BLUE_GRAY, step1_points)
pygame.draw.polygon(screen, BLUE_GRAY, step2_points)
# Draw a dark blue-gray outline.
pygame.draw.polygon(screen, DARK_BLUE_GRAY, step1_points, 2)
pygame.draw.polygon(screen, DARK_BLUE_GRAY, step2_points, 2)

'''
Draw the body of the house,
color it and add accents
'''
# Draw the outline of the house
house_base_points = [
    (11*SCALE + OFFSET, 20*SCALE), # Start on the left
    (11*SCALE + OFFSET, 12*SCALE), # Go up
    (24*SCALE + OFFSET, 12*SCALE), # To the right
    (24*SCALE + OFFSET, 20*SCALE)  # Go down
]
# Draw the house body in sea_green.
pygame.draw.polygon(screen, SEA_GREEN, house_base_points) 
# Draw a dark_green outline to match the sketch
pygame.draw.polygon(screen, DARK_GREEN, house_base_points, 3)

'''
Draw the door
its color and accents
'''
# draw the door frame of the house
door_house = [
    (16*SCALE + OFFSET, 20*SCALE),
    (16*SCALE + OFFSET, 17*SCALE),
    (19*SCALE + OFFSET, 17*SCALE),
    (19*SCALE + OFFSET, 20*SCALE)
]
# color the door 
pygame.draw.polygon(screen, (71,108,63), door_house)
# color the door border
pygame.draw.polygon(screen, (63,108,83), door_house, 2)

'''
Draw a window
create a shape that resembles a window
'''
# 1. Identify the rectangular frame surrounding the semicircle (Rect1)
# (x, y, width, height)
window_rect1 = (12*SCALE + OFFSET, 13*SCALE, 4*SCALE, 4*SCALE)
# Pour yellow paint into the window
pygame.draw.ellipse(screen, YELLOW_CENTER, window_rect1, 0)
# a. Draw an arc (upper half)
# Parameters: (screen, color, rectangle_bound, start_angle, end_angle, thickness)
pygame.draw.arc(screen, PURPLE, window_rect1, 0, math.pi, 3)
# b. Draw a horizontal line at the bottom to form a semicircle.
pygame.draw.line(screen, PURPLE, 
                 (12*SCALE + OFFSET, 15*SCALE), 
                 (16*SCALE + OFFSET, 15*SCALE), 3)
# 2. Define the rectangular frame surrounding the semicircle (Rect2)
# (x, y, width, height)
window_rect2 = (19*SCALE + OFFSET, 13*SCALE, 4*SCALE, 4*SCALE)
# Pour yellow paint inside the right window.
pygame.draw.ellipse(screen, YELLOW_CENTER, window_rect2, 0)
# a. Draw an arc (upper half)
# Parameters: (screen, color, rectangle_bound, start_angle, end_angle, thickness)
pygame.draw.arc(screen, PURPLE, window_rect2, 0, math.pi, 3)
# b. Draw a horizontal line at the bottom to form a semicircle.
pygame.draw.line(screen, PURPLE, 
                 (19*SCALE + OFFSET, 15*SCALE), 
                 (23*SCALE + OFFSET, 15*SCALE), 3)
# 3. Draw a green overlay to cover the bottom half of the yellow circle.
pygame.draw.rect(screen, SEA_GREEN, (12*SCALE + OFFSET, 15*SCALE, 4*SCALE, 2*SCALE)) # left box
pygame.draw.rect(screen, SEA_GREEN, (19*SCALE + OFFSET, 15*SCALE, 4*SCALE, 2*SCALE)) # right box
# 4. Create stripes to resemble a house with a door frame.
pygame.draw.line(screen, GRAY,
                 (14*SCALE + OFFSET, 13*SCALE),
                 (14*SCALE + OFFSET, 15*SCALE), 2) # vertical line for the left window
pygame.draw.line(screen, GRAY,
                 (21*SCALE + OFFSET, 13*SCALE),
                 (21*SCALE + OFFSET, 15*SCALE), 2) # vertical line for the right window

'''
Storage room in the attic
with pieces of brick
'''
# Run a loop from cell 10 to cell 25.
for row in [10, 11]: # Run for row 10 and row 11
    for col in range(10, 25): # along the small squares from 10 to 25
        # Color the squares
        pygame.draw.rect(screen, (160, 82, 45), (col*SCALE + OFFSET, row*SCALE, SCALE, SCALE))
        # border for tiles
        pygame.draw.rect(screen, PURPLE, (col*SCALE + OFFSET, row*SCALE, SCALE, SCALE), 1)

''' 
Roof
'''
pygame.draw.polygon(screen, (178, 40, 73), [(10*SCALE + OFFSET, 10*SCALE), (17*SCALE + OFFSET, 7*SCALE), (25*SCALE + OFFSET, 10*SCALE)]) # Draw filled triangle
pygame.draw.polygon(screen, (70, 12, 25), [(10*SCALE + OFFSET, 10*SCALE), (17*SCALE + OFFSET, 7*SCALE), (25*SCALE + OFFSET, 10*SCALE)], 2) # roof eaves

'''
Home decor
'''
pygame.draw.circle(screen, RED, (17*SCALE + OFFSET, 7*SCALE), 10) # Draw filled circle
pygame.draw.circle(screen, SKY_BLUE, (17*SCALE + OFFSET, 7*SCALE), 6) # DDraw a circle and fill in the outline

'''
Draw a fence around the house
with alternating open spaces.
'''
# Draw only in odd-numbered places to create gaps in the fence
    # Color and layout for the horizontal fence on the left.
pygame.draw.rect(screen, (139, 69, 19), (1*SCALE + OFFSET, 19*SCALE, 9*SCALE, SCALE/2))
pygame.draw.rect(screen, (139, 69, 19), (1*SCALE + OFFSET, 21*SCALE, 9*SCALE, SCALE/2))
    # Color and layout the horizontal fence on the right.
pygame.draw.rect(screen, (139, 69, 19), (25*SCALE + OFFSET, 19*SCALE, 9*SCALE, SCALE/2))
pygame.draw.rect(screen, (139, 69, 19), (25*SCALE + OFFSET, 21*SCALE, 9*SCALE, SCALE/2))
    # Coloring and layout for the vertical fence.
for i in range(1, 10, 2): # left
    pygame.draw.rect(screen, (139, 69, 19), (i*SCALE + OFFSET, 18*SCALE, SCALE, 4*SCALE))
for i in range(25, 34, 2): # right
    pygame.draw.rect(screen, (139, 69, 19), (i*SCALE + OFFSET, 18*SCALE, SCALE, 4*SCALE))

''' 
Draw the stars using bright circles.
'''
# Draw 10 small yellow stars
for i in range(20):
    x_star = random.randint(0, 800) # Random x-coordinate from 0 to 800 (or screen width)
    y_star = random.randint(0, 6*SCALE) # Random y-coordinate from 0 to 6 * SCALE (to indicate location in the airspace)
    size = random.randint(1, 2) # Draw a star with a random size from 1 to 2 pixels for a more lively effect
    pygame.draw.circle(screen, YELLOW, (x_star, y_star), size)

'''
Draw a big star
'''
# 10-point coordinates of the star (x, y)
# Use SCALE to maintain scale and OFFSET to align with the grid
star_points = [
    (30*SCALE + OFFSET, 3*SCALE), # top
    (30.5*SCALE + OFFSET, 4*SCALE), # right-side indentation
    (31.5*SCALE + OFFSET, 4*SCALE), # right top
    (30.7*SCALE + OFFSET, 4.8*SCALE), # right lower indentation
    (31*SCALE + OFFSET, 5.8*SCALE), # bottom right
    (30*SCALE + OFFSET, 5.2*SCALE), # bottom recess
    (29*SCALE + OFFSET, 5.8*SCALE), # bottom left
    (29.3*SCALE + OFFSET, 4.8*SCALE), # concave lower left
    (28.5*SCALE + OFFSET, 4*SCALE), # top left
    (29.5*SCALE + OFFSET, 4*SCALE) # left concave
]
pygame.draw.polygon(screen, YELLOW, star_points,0) # Draw a solid yellow star (thickness = 0)
pygame.draw.polygon(screen,YELLOW_CENTER, star_points, 2) #add a border

'''
Draw the moon
crescent moon in the sky
'''
# Draw a yellow full moon.
pygame.draw.circle(screen, YELLOW, (200, 100), 40)
# Draw a black circle (background color) over it to create a gap.
# Slightly to the right and down (220, 100)
pygame.draw.circle(screen, BLACK, (225, 100), 30)

'''
Draw a lake
'''
pygame.draw.ellipse(screen, BLUE, (100, 400, 200, 100), 0) # Draw filled ellipse

'''
Draw a tree
'''
# 1. Stem (brown)
pygame.draw.rect(screen, BROWN, (35*SCALE + OFFSET, 17*SCALE, 1.5*SCALE, 8*SCALE))
# 2. Tree
root_x = 35*SCALE + OFFSET + (0.75*SCALE)
root_y = 17*SCALE
pygame.draw.circle(screen, DARK_GREEN, (root_x, root_y), 5*SCALE)
# pygame.draw.(screen, GREEN, (20*SCALE+OFFSET, 17* SCALE),  (*SCALE+OFFSET,  ),0)
# 3. Foliage
for i in range (15):
    # Create random deviation around the top of the tree trunk
    leaf_x = root_x + random.uniform(-4 * SCALE, 4 * SCALE)
    leaf_y = root_y + 99 + random.uniform(-0.5 * SCALE, 0.5 * SCALE) # 17 is the peak, +99 is the bottom
    # Draw leaves with random radii
    radius = random.uniform(0.3 * SCALE, 0.6 * SCALE)
    pygame.draw.circle(screen, GREEN, (leaf_x, leaf_y), radius)

'''
Draw a dog
'''
# 1. The dog's body
pygame.draw.rect(screen, ORANGE, (5*SCALE + OFFSET, 23*SCALE, 5*SCALE, 2.5*SCALE))
# 2. Dog's head
pygame.draw.rect(screen, ORANGE, (10*SCALE + OFFSET, 22*SCALE, 2.5*SCALE, 2.5*SCALE))
# 3. Dog ears
pygame.draw.polygon(screen, ORANGE,
                    [(9*SCALE + OFFSET, 21*SCALE),
                    (10*SCALE + OFFSET, 21*SCALE),
                    (10*SCALE + OFFSET, 22*SCALE)])
pygame.draw.polygon(screen, ORANGE,
                    [(11*SCALE + OFFSET, 21*SCALE),
                     (12*SCALE + OFFSET, 21*SCALE),
                     (11*SCALE + OFFSET, 22*SCALE)])
# 4. Dog tail
pygame.draw.polygon(screen, ORANGE,
                    [(4*SCALE + OFFSET, 22*SCALE),
                     (5*SCALE + OFFSET, 23*SCALE),
                     (4*SCALE + OFFSET, 23*SCALE)])
# 5. Dog paws
pygame.draw.line(screen, ORANGE, (5.5*SCALE + OFFSET, 25.5*SCALE), (5.5*SCALE + OFFSET, 27*SCALE), 4) # Left hind leg
pygame.draw.line(screen, ORANGE, (6.5*SCALE + OFFSET, 25.5*SCALE), (6.5*SCALE + OFFSET, 27*SCALE), 4) # Right hind leg
pygame.draw.line(screen, ORANGE, (7.5*SCALE + OFFSET, 25.5*SCALE), (7.5*SCALE + OFFSET, 27*SCALE), 4) # Front leg (left)
pygame.draw.line(screen, ORANGE, (8.5*SCALE + OFFSET, 25.5*SCALE), (8.5*SCALE + OFFSET, 27*SCALE), 4) # Front leg (right)
# 6. Eyes and nose
pygame.draw.circle(screen, BLACK, (11*SCALE + OFFSET, 23*SCALE), 2) # Eyes (black, with small dots)
pygame.draw.circle(screen, BLACK, (12.5*SCALE + OFFSET, 23.5*SCALE), 3) # Nose (black, located near the right edge of the head)

'''
Dog bones
'''
# Ground coordinates under the dog's paws
dog_ground_x = 8.5*SCALE + OFFSET
dog_ground_y = 27*SCALE
# Draw 5-7 scattered bone patterns.
for i in range(7):
    bone_x = dog_ground_x + random.uniform(-4*SCALE, 4*SCALE) # Scatter bones around the area near the dog
    bone_y = dog_ground_y + random.uniform(0, 0.5*SCALE) # Lay the bone flat on the ground
    #Draw a small white bone
    #bone size
    pygame.draw.rect(screen, WHITE, (bone_x, bone_y, 0.9*SCALE, 0.4*SCALE))
    # Shape the bone (by drawing two dots at each end)
    pygame.draw.circle(screen, WHITE, (bone_x, bone_y + 0.1*SCALE), 0.15*SCALE)
    pygame.draw.circle(screen, WHITE, (bone_x + 0.4*SCALE, bone_y + 0.1*SCALE), 0.15*SCALE)

pygame.display.update() # Call this function to update the display after drawing

# Pygame main loop - For now this just handles quitting the window
while True:
    # Process player inputs.
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            raise SystemExit
    clock.tick(60)         # wait until next frame (at 60 FPS)