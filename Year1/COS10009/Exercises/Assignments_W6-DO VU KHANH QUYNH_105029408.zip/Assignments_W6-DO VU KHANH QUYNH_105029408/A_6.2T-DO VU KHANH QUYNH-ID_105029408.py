class Track:
    def __init__(self, name, location):
        self.name = name
        self.location = location

def read_tracks(music_file):
    count = int(music_file.readline().strip())
    tracks = []
    # Put a while loop here which increments an index to read the tracks
    i = 0
    while i < count:
        track = read_track(music_file)
        tracks.append(track)
        i += 1
    return tracks

def read_track(music_file):
    # Replace with code
    # Complete this function
    # You need to create a Track here.
    name = music_file.readline().strip()
    location = music_file.readline().strip()
    return Track(name, location)
    
def print_tracks(tracks):
    # Replace with code
    # Use a while loop with a control variable index
    # to print each track. Use tracks.length to determine how
    # many times to loop.
    # Print each track use: tracks[index] to get each track record
    i = 0 
    while i < len(tracks):
        print_track(tracks[i])
        i += 1

def print_track(track):
    print(f"Track Name: {track.name}")
    print(f"Track Location: {track.location}")

def main():
    music_file = open("input.txt", "r") # Open for reading
    tracks = read_tracks(music_file)
    # tracks = [Track("Cracking ...", "./sounds/..a."), Track(""), Track("")]
    # print(tracks)
    #Print all the tracks
    print_tracks(tracks)
    music_file.close()

if __name__ == "__main__":
    main()