# It is suggested that you put together code from your 
# previous tasks to start this. eg:
# 8.1T Read Album with Tracks
import input_functions

# Dictionary mapping genre numbers (from file) to genre names
# Used when displaying album information
GENRE = {
    1 : "Pop",
    2 : "Classic",
    3 : "Jazz",
    4 : "Rock"
}      

# Album class represents a music album object
# Each album contains artist name, album title, release year,
# genre number and a list of tracks
class Album():
    def __init__(self, artist_name, album_name, release_date, genre, tracks):
        self.artist_name = artist_name
        self.album_name = album_name
        self.release_date = release_date
        self.genre = genre
        self.tracks = tracks

# Track class represents a single song
# Each track has a name and a file location
class Track():
    def __init__(self, name, location):
        self.name = name
        self.location = location

# Displays the main menu options to the user
def menu():
    print("\nMusic Player")
    print("1. Read in Albums")
    print("2. Display Albums")
    print("3. Select an Album to play")
    print("4. Exit the application")

# Reads album data from a text file
# Returns a list of Album objects
def read_file():
    filename = input("Enter filename: ")
    filename = filename + ".txt"
    try:
        music_file = open(filename, "r")
    except:
        print("File not found")
        return[]
    albums = []
    count = int(music_file.readline().strip())
    i = 0
    while i < count:
        album = read_album(music_file)
        albums.append(album)
        i += 1
    music_file.close()
    return albums

# Reads one album from file and creates an Album object
def read_album(music_file):
    artist_name = music_file.readline().strip()
    album_name = music_file.readline().strip()
    release_date = music_file.readline().strip()
    genre = int(music_file.readline().strip())
    tracks = read_tracks(music_file)
    album = Album(artist_name, album_name, release_date, genre, tracks)
    return album

# Returns a list of Track objects
def read_track(music_file):
    name = music_file.readline().strip()
    location = music_file.readline().strip()
    return Track(name, location)

# Reads all tracks for one album
def read_tracks(music_file):
    count = int(music_file.readline().strip())
    tracks = []
    i = 0
    while i < count:
        track = read_track(music_file)
        tracks.append(track)
        i += 1
    return tracks

# Prints the details of a single album including artist,
# album name, release year, genre and all tracks
def print_album(album):
    print(f"{album.artist_name}")
    print(f"{album.album_name}")
    print(f"{album.release_date}")
    print(f"{GENRE[album.genre]}")
    print_tracks(album.tracks)

# Displays all albums in the list with index numbers
def print_albums(albums):
    i = 0
    while i < len(albums):
        print(f"{i+1}. {albums[i].artist_name} - {albums[i].album_name} - {albums[i].release_date} - {GENRE[albums[i].genre]}")
        i += 1

# Displays the name and file location of a track
def print_track(track):
    print(f"{track.name}")
    print(f"{track.location}")

# Displays all tracks in the album with numbering
def print_tracks(tracks):
    i = 0
    while i < len(tracks):
        print(i + 1, tracks[i].name)
        print(tracks[i].location)
        i += 1

# Displays all albums that belong to the selected genre
def print_albums_by_genre(albums, genre):
    i = 0
    while i < len(albums):
        if albums[i].genre == genre:
            print(f"{albums[i].artist_name} - {albums[i].album_name} - {albums[i].release_date} - {GENRE[albums[i].genre]}")
        i += 1

# Allows user to choose an album from the list
# Returns the selected Album object
def select_album(albums):
    print_albums(albums)
    choice = input_functions.read_int_in_range("Select album: ", 1, len(albums))
    return albums[choice - 1]

# Allows user to choose a track from an album
# Returns the selected Track object
def select_track(album):
    print_tracks(album.tracks)
    choice = input_functions.read_int_in_range("Select track: ", 1, len(album.tracks))
    return album.tracks[choice - 1]

# Simulates playing a track by displaying track information
def play_track(track):
    print("\nNow Playing")
    print_track(track)

# Main program loop controlling the music player
def main(): 
    albums = []
    finished = False
    while finished == False:
        menu()
        choice = input_functions.read_int_in_range("Please enter your choice: ", 1, 4)
        match choice:
            case 1:
                albums = read_file()
            case 2:
                print("1. Display all albums")
                print("2. Display albums by genre")
                choice = input_functions.read_int_in_range("Choice: ", 1, 2)
                match choice:
                    case 1:
                        print_albums(albums)
                    case 2:
                        print("\nGenres")
                        print("1 Pop")
                        print("2 Classic")
                        print("3 Jazz")
                        print("4 Rock")
                        genre = input_functions.read_int_in_range("Select genre: ", 1, 4)
                        print_albums_by_genre(albums, genre)
            case 3:
                if len(albums) == 0:
                    print("No album loaded")
                else:
                    album = select_album(albums)
                    track = select_track(album)
                    play_track(track)
            case 4:
                finished = True
            case _:
                print("Please select again")
        
              


if __name__ == "__main__":
    main()