import pygame
import sys
import music_data
import time

# Constants
WIN_WIDTH = 900
WIN_HEIGHT = 600

TOP_COLOR = (30, 177, 250)
BOTTOM_COLOR = (29, 77, 181)

selected_album = None
selected_tracks = []
last_click_time = 0
current_song = ""

# Initialization
def init():
    global track_font, title_font

    pygame.init()
    pygame.mixer.init()

    screen = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
    pygame.display.set_caption("Music Player")

    track_font = pygame.font.SysFont(None, 24)
    title_font = pygame.font.SysFont(None, 32, bold=True)
    return screen

# Put your record definitions here

# Load albums and tracks
def load_albums():
    # Put in your code here to load albums and tracks
    return music_data.read_file()

# Draw a coloured background using TOP_COLOR and BOTTOM_COLOR
def draw_background(screen):
    # complete this code
    screen.fill((215, 125, 242))

# Draw the artwork on the screen for all the albums
def draw_albums(screen, albums):
    # complete this code
    x = 50
    y =50
    for i, album in enumerate(albums):
        try:
            image = pygame.image.load(f"pic_{i+1}.png")
            image = pygame.transform.scale(image, (150, 150))
            screen.blit(image, (x, y))
        except:
            pygame.draw.rect(screen, (200,200,200), (x,y,150,150))
        screen.blit(track_font.render(album.album_name, True, (0,0,0)), (x, y+160))
        x += 200
        if x > 400:
            x = 50
            y += 200

# Draws the album images and the track list
# Complete the missing code
def draw(screen, albums):
    draw_background(screen)
    draw_albums(screen, albums)
    mouse_x, mouse_y = pygame.mouse.get_pos()

    if selected_album:
        y = 50
        for track in selected_tracks:
            # hover
            if 470 <= mouse_x <= 800 and y <= mouse_y <= y+30:
                color = (0, 100, 255)
            else:
                color = (255,0,0) if track.name == current_song else (0,0,0)
            screen.blit(track_font.render(track.name, True, color), (470, y))
            y += 40

    # now playing
    if current_song:
        screen.blit(
            title_font.render("Now Playing: " + current_song, True, (255,255,0)),
            (50, 550))
    pygame.display.flip()

# Detects if a 'mouse sensitive' area has been clicked on
# returns True or False
def area_clicked(leftX, topY, rightX, bottomY):
    # complete this code
    x, y = pygame.mouse.get_pos()
    return leftX <= x <= rightX and topY <= y <= bottomY

# Mouse Click Handling
def handle_mouse_click(albums):
    global last_click_time, selected_album, selected_tracks

    now = time.time()
    if now - last_click_time < 0.1:
        return
    last_click_time = now

    # album click
    x, y = 50, 50
    for album in albums:
        if area_clicked(x, y, x+150, y+150):
            selected_album = album
            selected_tracks = album.tracks
        x += 200
        if x > 400:
            x = 50
            y += 200

    # track click
    track_y = 50
    for i, track in enumerate(selected_tracks):
        if area_clicked(470, track_y, 800, track_y+30):
            play_track(i, selected_album)
        track_y += 40

# Takes a String title and an Integer ypos
# You may want to use the following
def display_track(screen, title, xpos, ypos):
    screen.blit(track_font.render(title, True, (0, 0, 0)), (xpos, ypos))

# Takes a track index and an album and plays the Track
def play_track(index, album):
    global current_song
    try:
        song_path = album.tracks[index].location
        pygame.mixer.music.stop()
        pygame.mixer.music.load(song_path)
        pygame.mixer.music.play()
        current_song = album.tracks[index].name
        print("Playing:", song_path)
    except Exception as e:
        print("Error:", e)

def toggle_pause():
    global paused
    if paused:
        pygame.mixer.music.unpause()
    else:
        pygame.mixer.music.pause()
    paused = not paused

# Update
def update():
    pass

def main():
    global selected_album, selected_tracks
    # Initialise
    screen = init()
    clock = pygame.time.Clock()

    albums = load_albums()
    print("Load alabums: ", len(albums))
    # Main Loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    handle_mouse_click(albums)

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    selected_album = None
                    selected_tracks = []
                if event.key == pygame.K_SPACE:
                    toggle_pause()

        # Update Logic
        update()
        # Draw
        draw(screen, albums)
        # Clock tick
        clock.tick(60)

if __name__ == "__main__":
    main()