import pygame
import sys
import music_data

# Constants
WIN_WIDTH = 800
WIN_HEIGHT = 600

TOP_COLOR = (30, 177, 250)
BOTTOM_COLOR = (29, 77, 181)

# Genre dictionary (replaces Ruby module)
GENRE = {
    "POP": 1,
    "CLASSIC": 2,
    "JAZZ": 3,
    "ROCK": 4
}

selected_album = None
selected_tracks = []

# Initialization
def init():
    global track_font

    pygame.init()
    pygame.mixer.init()

    screen = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
    pygame.display.set_caption("Music Player")

    track_font = pygame.font.SysFont(None, 24)

    return screen

# Put your record definitions here

# Load albums and tracks
def load_albums():
    # Put in your code here to load albums and tracks
    return music_data.read_file()

# Draw a coloured background using TOP_COLOR and BOTTOM_COLOR
def draw_background(screen):
    # complete this code
    screen.fill((0, 128, 255))

# Draw the artwork on the screen for all the albums
def draw_albums(screen, albums):
    # complete this code
    x = 50
    y =50
    for i, album in enumerate(albums):
        try:
            image = pygame.image.load(f"pic_{i+1}.png")
            image = pygame.transform.scale(image, (150, 150))
            screen.blit(image, (x, y))
        except:
            print("Cannot load image")
        # pygame.draw.rect(screen, (0, 255, 255), (x, y, 150, 150))
        # pygame.image.load("pic_1")
        display_track(screen, album.album_name, x, y + 160)
        # move anohter place to draw a new album
        x += 200
        # linebreak if width is exceeded
        if x > 400:
            x = 50
            y += 200

# Draws the album images and the track list
# Complete the missing code
def draw(screen, albums):
    draw_background(screen)
    draw_albums(screen, albums)
    if selected_album:
        y = 50
        for track in selected_tracks:
            display_track(screen, track.name, 500, y)
            y += 40
    pygame.display.flip()

# Detects if a 'mouse sensitive' area has been clicked on
# returns True or False
def area_clicked(leftX, topY, rightX, bottomY):
    # complete this code
    mouse_x, mouse_y = pygame.mouse.get_pos()
    if leftX <= mouse_x <= rightX and topY <= mouse_y <= bottomY:
        return True
    return False

# Mouse Click Handling
def handle_mouse_click(albums):
    # What should happen here?
    global selected_album, selected_tracks 
    x = 50
    y = 50
    # click album
    for album in albums:
        if area_clicked(x, y, x+150, y+150):
            selected_album = album
            selected_tracks = album.tracks
        x += 200
        if x > 400:
            x = 50
            y += 200
    # click track
    track_y = 50
    for i, track in enumerate(selected_tracks):
        if area_clicked(500, track_y, 800, track_y + 30):
            play_track(i, selected_album)
        track_y += 40

# Takes a String title and an Integer ypos
# You may want to use the following
def display_track(screen, title, xpos, ypos):
    screen.blit(track_font.render(title, True, (0, 0, 0)), (xpos, ypos))

# Takes a track index and an album and plays the Track
def play_track(track, album):
    # complete the missing code
    song_location = album.tracks[track].location
    pygame.mixer.music.load(song_location)
    pygame.mixer.music.play()

# Update
def update():
    pass

def main():
    # Initialise
    screen = init()
    clock = pygame.time.Clock()

    albums = load_albums()
    print("Load alabums: ", len(albums))
    # Main Loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    handle_mouse_click(albums)

        # Update Logic
        update()
        # Draw
        draw(screen, albums)
        # Clock tick
        clock.tick(60)


if __name__ == "__main__":
    main()