import input_functions

# It is suggested that you put together code from your 
# previous tasks to start this. eg:
# Pass Level Music Player
GENRE = {
    1: "Pop",
    2: "Classic",
    3: "Jazz",
    4: "Rock"
}

class Album():
    def __init__(self, artist_name, album_name, release_date, genre, tracks):
        self.artist_name = artist_name
        self.album_name = album_name
        self.release_date = release_date
        self.genre = genre
        self.tracks = tracks
        
class Track():
    def __init__(self, name, location):
        self.name = name
        self.location = location

def menu():
    print("\nMenu: ")
    print("1. Read in Albums")
    print("2. Display Albums")
    print("3. Select an Album to play")
    print("4. Update an existinng Album")
    print("5. Exit the application")

# option 1
def read_file():
    filename = 'albums.txt'
    try:
        music_file = open(filename, "r")
    except:
        print("File not found")
        return[]
    count = int(music_file.readline().strip())
    albums = []
    i = 0
    while i < count:
        album = read_album(music_file)
        albums.append(album)
        i += 1
    music_file.close()
    return albums

# option 2.1
def read_album(music_file):
    artist_name = music_file.readline().strip()
    album_name = music_file.readline().strip()
    release_date = music_file.readline().strip()
    genre = int(music_file.readline().strip())
    tracks = read_tracks(music_file)
    album = Album(artist_name, album_name, release_date, genre, tracks)
    return album

def read_track(music_file):
    name = music_file.readline().strip()
    location = music_file.readline().strip()
    track = Track(name, location)
    return track

def read_tracks(music_file):
    count = int(music_file.readline().strip())
    tracks = []
    i = 0
    while i < count:
        track = read_track(music_file)
        tracks.append(track)
        i+= 1
    return tracks

def print_album(album):
    print(f"The artist name: {album.artist_name}")
    print(f"The album name: {album.album_name}")
    print(f"The release date of the album: {album.release_date}")
    print(f"The genre of the album: {GENRE[album.genre]}")
    print_tracks(album.tracks)

def print_albums(albums):
    i = 0
    while i < len(albums):
        print(f"{i+1}. {albums[i].artist_name} - {albums[i].album_name} - {albums[i].release_date} - {GENRE[albums[i].genre]}")
        i += 1
    
def print_track(track):
    print(track.name)
    print(track.location)

def print_tracks(tracks):
    i = 0
    while i < len(tracks):
        print(i+1, tracks[i].name)
        print(tracks[i].location)
        i += 1
    
# option 2.2
def menu_genre():
    print("\nGenres: ")
    print("1. Pop")
    print("2. Classic")
    print("3. Jazz")
    print("4. Rock")

def print_choice_genre(albums, genre):
    i = 0
    while i < len(albums):
        if albums[i].genre == genre:
            print(f"{albums[i].artist_name} - {albums[i].album_name} - {albums[i].release_date} - {GENRE[albums[i].genre]}")
        i += 1

# option 3
def select_album(albums):
    print_albums(albums)
    choice = input_functions.read_int_in_range("Select album: ", 1, len(albums))
    return albums[choice -1]

def select_track(album):
    if len(album.tracks) == 0:
        print("No track available in this album")
        return None
    print_tracks(album.tracks)
    choice = input_functions.read_int_in_range("Select track: ", 1, len(album.tracks))
    return album.tracks[choice - 1]

def play_track(track):
    print("\nNow Playing: ")
    print_track(track)

# option 4
def print_album_info(album):
    print(f"The artist name: {album.artist_name}")
    print(f"The album name: {album.album_name}")
    print(f"The release date of the album: {album.release_date}")
    print(f"The genre of the album: {GENRE[album.genre]}")

def print_change():
    print("\nChange its title or genre: ")
    print("1. Update album name")
    print("2. Update genre")

def update_album_name(album):
    new_name = input_functions.read_string("Enter new album name: ")
    album.album_name = new_name

def update_album_genre(album):
    menu_genre()
    new_genre = input_functions.read_int_in_range("Enter a new genre: ", 1, 4)
    album.genre = new_genre

def main():
    finished = False
    while finished == False:
        menu()
        choice = input_functions.read_int_in_range("Your option: ", 1, 5)
        match choice:
            case 1:
                albums = read_file()
            case 2:
                print("1. Display all albums")
                print("2. Display all albums for a particular genre")
                choice = input_functions.read_int_in_range("Your choice: ", 1, 2)
                match choice:
                    case 1:
                        print_albums(albums)
                    case 2:
                        menu_genre()
                        genre = input_functions.read_int_in_range("Select genre: ", 1, 4)
                        print_choice_genre(albums, genre)
            case 3:
                if len(albums) == 0:
                    print("No album loaded")
                    return None
                else:
                    album = select_album(albums)
                    track = select_track(album)
                    if track is not None:
                        play_track(track)
            case 4:
                if len(albums) == 0:
                    print("No album loaded")
                else:
                    album = select_album(albums)
                    print_change()
                    choice_update = input_functions.read_int_in_range("Select update: ", 1, 2)
                    match choice_update:
                        case 1:
                            update_album_name(album)
                        case 2:
                            update_album_genre(album)
                    print("\nUpdate album: ")
                    print_album_info(album)
                    input("Press enter to return")
            case 5:
                finished = True
            case _:
                print("Please select again")

if __name__ == "__main__":
    main()

