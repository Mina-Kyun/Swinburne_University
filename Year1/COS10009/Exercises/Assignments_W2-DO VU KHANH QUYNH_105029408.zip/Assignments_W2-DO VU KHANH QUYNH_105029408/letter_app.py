import input_functions as input_function

# A function that returns the letter label
def get_letter_label():
    user_input_tile = input_function.read_string("Please enter your tile (Mr, Mrs, Miss, Dr, Ms): ")
    user_input_first_name = input_function.read_string("Please enter your first name: ")
    user_input_last_name = input_function.read_string("Please enter your last name: ")
    user_input_hours_or_unit_number = input_function.read_integer("Please enter the hours or unit number: ")
    user_input_stress_name = input_function.read_string("Please enter the stress name: ")
    user_input_suburd = input_function.read_string("Please enter the suburd: ")
    user_input_postcode = input_function.read_integer_in_range("Pleae enter a postcode:", 0000, 9999)
    return f"{user_input_tile} {user_input_first_name} {user_input_last_name}\n {user_input_hours_or_unit_number} {user_input_stress_name}\n {user_input_suburd} {user_input_postcode}"

# A function that returns the letter message
def get_letter_message():
    user_input_message_subject_line = input_function.read_string("Please enter your message subject line: ")
    user_input_messege_content = input_function.read_string("Please enter your message content: ")
    return f"{user_input_message_subject_line}\n {user_input_messege_content}"

# A procedure that prints the label and message
def print_letter():
    my_letter_label = ''
    my_letter_message = ' '
    print(my_letter_label + '\n' + my_letter_message)
    my_letter_label = get_letter_label()
    my_letter_message = get_letter_message()


# Display to print
def main():
    print_letter()

main()