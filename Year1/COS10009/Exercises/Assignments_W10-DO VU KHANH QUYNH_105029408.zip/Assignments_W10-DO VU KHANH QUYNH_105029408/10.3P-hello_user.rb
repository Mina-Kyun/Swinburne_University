puts "Enter your name: "
name = gets.chomp
puts "Hello, #{name}!"
puts "Enter your age: "
number = gets.chomp
puts "You are #{number} years old"
